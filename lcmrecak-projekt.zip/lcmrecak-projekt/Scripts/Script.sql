USE nwtis_g3;

#minimalno 100.000 preuzetih polazaka/dolazaka s aerodroma 
SELECT COUNT(*) as "Broj polazaka" FROM AERODROMI_POLASCI;

SELECT COUNT(*) as "Broj dolazaka" FROM AERODROMI_DOLASCI;

#minimalno 15 dana u cijelosti za koje su preuzeti podaci polazaka i dolazaka 
SELECT COUNT(DISTINCT (FROM_UNIXTIME(ap.lastSeen , '%d. %m. %Y'))) as "Broj dana" FROM AERODROMI_POLASCI ap;
SELECT FROM_UNIXTIME(ap.lastSeen, '%d. %m. %Y') Dan, count(*) as "Broj polazaka po danu" FROM AERODROMI_POLASCI ap GROUP BY Dan;

SELECT COUNT(DISTINCT (FROM_UNIXTIME(ad.firstSeen , '%d. %m. %Y'))) as "Broj dana" FROM AERODROMI_DOLASCI ad;
SELECT FROM_UNIXTIME(ad.firstSeen, '%d. %m. %Y') Dan, count(*) as "Broj dolazaka po danu" FROM AERODROMI_DOLASCI ad GROUP BY Dan;

# broj preuzetih podataka po danima za sve aerodrome
SELECT FROM_UNIXTIME(ap.lastSeen, '%d. %m. %Y') Dan, count(*) as "Broj polazaka po danu" FROM AERODROMI_POLASCI ap GROUP BY Dan;

SELECT FROM_UNIXTIME(ad.firstSeen, '%d. %m. %Y') Dan, count(*) as "Broj dolazaka po danu" FROM AERODROMI_DOLASCI ad GROUP BY Dan;

#broj preuzetih podataka po danima za sve aerodrome pojedinačno 
SELECT ap.estDepartureAirport as "Aerodrom",  FROM_UNIXTIME(ap.lastSeen, '%d. %m. %Y') Dan, count(*) as "Broj polazaka po danu" FROM AERODROMI_POLASCI ap GROUP BY 1, Dan ORDER BY 1;

SELECT ad.estArrivalAirport  as "Aerodrom",  FROM_UNIXTIME(ad.firstSeen , '%d. %m. %Y') Dan, count(*) as "Broj dolazaka po danu" FROM AERODROMI_DOLASCI ad GROUP BY 1, Dan ORDER BY 1;

#broj preuzetih podataka po danima za odabrani aerodrome
SELECT ap.estDepartureAirport as "Aerodrom",  FROM_UNIXTIME(ap.lastSeen, '%d. %m. %Y') Dan, count(*) as "Broj polazaka po danu" FROM AERODROMI_POLASCI ap WHERE ap.estDepartureAirport  = 'LOWW' GROUP BY 1, Dan ORDER BY 1;

SELECT ad.estArrivalAirport  as "Aerodrom",  FROM_UNIXTIME(ad.firstSeen , '%d. %m. %Y') Dan, count(*) as "Broj dolazaka po danu" FROM AERODROMI_DOLASCI ad WHERE ad.estArrivalAirport  = 'LDZA' GROUP BY 1, Dan ORDER BY 1;





