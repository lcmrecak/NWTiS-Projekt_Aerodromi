package org.foi.nwtis.lcmrecak.projekt;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.SocketException;
import java.nio.charset.Charset;

public class KorisnikGlavni {

	public static void main(String[] args) {
		KorisnikGlavni korisnikGlavni = new KorisnikGlavni();
		if(args.length==1) {
			String odgovor = korisnikGlavni.posaljiKomandu("localhost", 8003, args[0]);
			System.out.println("KORISNIK: "+odgovor);
		}
		else if(args.length==2) {
			String odgovor = korisnikGlavni.posaljiKomandu("localhost", 8003, args[0]+" "+args[1]);
			System.out.println("KORISNIK: "+odgovor);
		}
	}

	public String posaljiKomandu(String adresa, int port, String komanda) {
        try (
                 Socket veza = new Socket(adresa, port);
                 InputStreamReader isr = new InputStreamReader(veza.getInputStream(),
                        Charset.forName("UTF-8"));
                 OutputStreamWriter osw = new OutputStreamWriter(veza.getOutputStream(),
                        Charset.forName("UTF-8"));) {  

            osw.write(komanda);
            osw.flush();
            veza.shutdownOutput();
            StringBuilder tekst = new StringBuilder();
            while (true) {
                int i = isr.read();
                if (i == -1) {
                    break;
                }
                tekst.append((char) i);
            }
            veza.shutdownInput();
            veza.close();
            return tekst.toString();
        } catch (SocketException e) {
            ispis(e.getMessage());
        } catch (IOException ex) {
            ispis(ex.getMessage());
        }
        return null;
    }

	private void ispis(String message) {
		System.out.println(message);
	}
}
