package org.foi.nwtis.lcmrecak.projekt;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.foi.nwtis.lcmrecak.vjezba_03.konfiguracije.Konfiguracija;
import org.foi.nwtis.lcmrecak.vjezba_03.konfiguracije.KonfiguracijaApstraktna;
import org.foi.nwtis.lcmrecak.vjezba_03.konfiguracije.NeispravnaKonfiguracija;
import org.foi.nwtis.podaci.Aerodrom;

import com.google.gson.Gson;

/**
 * Glavna klasa za obradu zahtjeva korisnika
 */
public class ServerGlavni {

	/** maksimalni broj cekaca. */
	private int maxCekaca = -1;
	
	/** broj porta za spajanje korisnika */
	private int port = 0;
	
	private int status = 0;
	
	/** veza za mrežnu utičnicu. */
	private Socket veza = null;
	
	/** kolekcija aerodroma. */
	private List<Aerodrom> aerodromi = new ArrayList<Aerodrom>();
	
	/** iso format za datum. */
	private static SimpleDateFormat isoDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	
	/** konfiguracijski podaci. */
	private static Konfiguracija konf = null;  

	/**
	 * Glavna/početna metoda.
	 *
	 * @param args argumenti
	 */
	public static void main(String[] args) {
		if(args.length != 1) {
			System.out.println("Nije definiran parametar konfiguracijske datoteke!");
			return;
		}
		
		if(!ucitajKonfiguracijskePodatke(args)) return;
		
		int port = Integer.parseInt(konf.dajPostavku("port"));
		int maxCekaca =  Integer.parseInt(konf.dajPostavku("maks.cekaca"));
		System.out.println("Server će se pokrenuti na portu: "+port);
		
		ServerGlavni server  = new ServerGlavni(port,maxCekaca);
		
		server.obradaZahtjeva();
	}

	/**
	 * Učitavanje konfiguracijski podataka.
	 *
	 * @param args argumenti
	 * @return true, ako je uspješno
	 */
	public static boolean ucitajKonfiguracijskePodatke(String[] args) {
		String nazivDatoteke = args[0];
		try {
			konf = KonfiguracijaApstraktna.preuzmiKonfiguraciju(nazivDatoteke);
		} catch (NeispravnaKonfiguracija e) {
			System.out.println("Problem s učitavnjem datoteke "+nazivDatoteke+"!");
			return false;
		}
		return true;
	}
	
	/**
	 * Konstruktor klase.
	 *
	 * @param port broj porta
	 * @param maxCekaca maksimalni broj čekača
	 */
	public ServerGlavni(int port, int maxCekaca) {
		this.port = port;
		this.maxCekaca = maxCekaca;
	}

	/**
	 * Obrada zahtjeva.
	 */
	public void obradaZahtjeva() {

		try (ServerSocket ss = new ServerSocket(this.port, this.maxCekaca)) {			
			while (true) {
				
				this.veza = ss.accept();
				DretvaZahtjeva dretva = new DretvaZahtjeva(this.veza,this.konf);
				dretva.start(); 
			}

		} catch (IOException ex) {
			Logger.getLogger(ServerGlavni.class.getName()).log(Level.SEVERE, null, ex);
		}

	}

	/**
	 * Dohvaćanje i povrat konfiguracije.
	 *
	 * @return konf
	 */
	public static Konfiguracija getKonf() {
		return konf;
	}	
	
	
	public class DretvaZahtjeva extends Thread {

		private Socket veza = null;
		private Konfiguracija konfig = null;

		public DretvaZahtjeva(Socket veza, Konfiguracija konf) {
			this.veza = veza;
			this.konfig = konf;
		}

		@Override
		public synchronized void start() {
			super.start();
		}

		/**
		 * Run dretve.
		 */
		@Override
		public void run() {

			try (InputStreamReader isr = new InputStreamReader(this.veza.getInputStream(), Charset.forName("UTF-8"));
					OutputStreamWriter osw = new OutputStreamWriter(this.veza.getOutputStream(),
							Charset.forName("UTF-8"));) {

				StringBuilder tekst = new StringBuilder();
				while (true) {
					int i = isr.read();
					if (i == -1) {
						break;
					}
					tekst.append((char) i);
				}
				System.out.println("SERVER: " + tekst.toString());
				this.veza.shutdownInput();

				String odgovor = obradiNaredbu(tekst);
				osw.write(odgovor);
				osw.flush();
				veza.shutdownOutput();
				veza.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		@Override
		public void interrupt() {

			super.interrupt();
		}
	}
	
	private String obradiNaredbu(StringBuilder tekst) {
		Pattern pStatus = Pattern.compile("^STATUS$");
		Pattern pInit = Pattern.compile("^INIT$");
		Pattern pLoad = Pattern.compile("^LOAD (?s).*$");
		Pattern pDistance = Pattern.compile("^DISTANCE ([A-Z]{4}) ([A-Z]{4})$");
		Pattern pClear = Pattern.compile("^CLEAR$");
		Pattern pQuit = Pattern.compile("^QUIT$");

		Matcher mStatus = pStatus.matcher(tekst.toString());
		Matcher mInit = pInit.matcher(tekst.toString());
		Matcher mLoad = pLoad.matcher(tekst.toString());
		Matcher mDistance = pDistance.matcher(tekst.toString());
		Matcher mClear = pClear.matcher(tekst.toString());
		Matcher mQuit = pQuit.matcher(tekst.toString());


		String odgovor = "ERROR 14: Neispravna komanda!";
		
		if(mStatus.matches()) {
			return odgovor = "OK " + status;
		}
		
		if(status==0) {
			if(mInit.matches()) {
				status = 1;
				odgovor = "OK";
			}
			else if(mQuit.matches()) {
				status = 0;
				odgovor = "OK";
			}
			else odgovor = "ERROR 01: Posluzitelj hibernira!";
		}
		else if(status == 1) {
			if(mLoad.matches()) {
				status = 2;
				ucitajAerodrome(tekst);
				int brojAerodroma = aerodromi.size();
				odgovor = "OK " + brojAerodroma;
			}
			else if(mQuit.matches()) {
				status = 0;
				odgovor = "OK";
				DretvaZahtjeva.interrupted();
			}
			else odgovor = "ERROR 02: Posluzitelj inicijaliziran, prima samo naredbu LOAD";
		}
		else if(status == 2 && (mDistance.matches() || mClear.matches() || mQuit.matches())) {
			if(mDistance.matches()) {
				odgovor = odradiNaredbuAerodromiUsporedba(tekst, odgovor);
			}
			else if(mClear.matches()) {
				aerodromi.clear();
				status = 0;
				odgovor = "OK";
			}
			else if(mQuit.matches()) {
				status = 0;
				odgovor = "OK";
			}
			else odgovor = "ERROR 03: Posluzitelj je vec inicijaliziran i aktivan";
		}
		
		return odgovor;
	}
	
	private void ucitajAerodrome(StringBuilder tekst) {
		Gson gson = new Gson();
		String tekst1 = tekst.toString();
		String tekst2 = tekst1.replace("LOAD ", "");
		aerodromi.addAll(Arrays.asList(gson.fromJson(tekst2, Aerodrom[].class)));
	}
	
	private String odradiNaredbuAerodromiUsporedba(StringBuilder tekst, String odgovor) {
		String[] p = tekst.toString().split(" ");
		String icao1 = p[1];
		String icao2 = p[2];
		Double gsPrvi = (double) 0;
		Double gdPrvi = (double) 0;
		Double gsDrugi = (double) 0;
		Double gdDrugi = (double) 0;

		Boolean postojiPrvi = false;
		Boolean postojiDrugi = false;

		for (Aerodrom a : aerodromi) {
			if (icao1.equals(a.getIcao())) {
				postojiPrvi = true;
				gsPrvi = Double.parseDouble(a.getLokacija().getLatitude());
				gdPrvi = Double.parseDouble(a.getLokacija().getLongitude());
			}
			if (icao2.equals(a.getIcao())) {
				postojiDrugi = true;
				gsDrugi = Double.parseDouble(a.getLokacija().getLatitude());
				gdDrugi = Double.parseDouble(a.getLokacija().getLongitude());
			}
		}

		if (!postojiPrvi || !postojiDrugi) {
			if(!postojiPrvi) odgovor = "ERROR 11: Ne postoji aerodrom " + icao1;
			if(!postojiDrugi) odgovor = "ERROR 12: Ne postoji aerodrom " + icao2;
			if(!postojiPrvi && !postojiDrugi) odgovor = "ERROR 13: Ne postoje uneseni aerodromi";
			
			return odgovor;
		}
		else {
			odgovor = izracunajUdaljenost(gsPrvi, gdPrvi, gsDrugi, gdDrugi).toString();
			return odgovor = "OK " + odgovor;
		}
		
	}

	private Integer izracunajUdaljenost(Double gsPrvi, Double gdPrvi, Double gsDrugi, Double gdDrugi) {
		gsPrvi = Math.toRadians(gsPrvi);
		gdPrvi = Math.toRadians(gdPrvi);
		gsDrugi = Math.toRadians(gsDrugi);
		gdDrugi = Math.toRadians(gdDrugi);

		double radijusZemlje = 6371.01;
		double udaljenost = radijusZemlje * Math.acos(Math.sin(gsPrvi) * Math.sin(gsDrugi)
				+ Math.cos(gsPrvi) * Math.cos(gsDrugi) * Math.cos(gdPrvi - gdDrugi));
		return (int) Math.round(udaljenost);
	}
	
	
}
