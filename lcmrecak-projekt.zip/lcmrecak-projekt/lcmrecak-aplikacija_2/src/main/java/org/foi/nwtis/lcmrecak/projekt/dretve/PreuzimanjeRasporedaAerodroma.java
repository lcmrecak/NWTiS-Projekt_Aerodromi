package org.foi.nwtis.lcmrecak.projekt.dretve;

import java.text.ParseException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.foi.nwtis.lcmrecak.projekt.podaci.AerodromDolasciDAO;
import org.foi.nwtis.lcmrecak.projekt.podaci.AerodromPolasciDAO;
import org.foi.nwtis.lcmrecak.projekt.podaci.AerodromPraceniDAO;
import org.foi.nwtis.lcmrecak.projekt.podaci.AerodromProblemiDAO;
import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.podaci.Aerodrom;
import org.foi.nwtis.rest.klijenti.NwtisRestIznimka;
import org.foi.nwtis.rest.klijenti.OSKlijent;
import org.foi.nwtis.rest.podaci.AvionLeti;

// TODO: Auto-generated Javadoc
/**
 * The Class PreuzimanjeRasporedaAerodroma.
 */
public class PreuzimanjeRasporedaAerodroma extends Thread {

	/** The preuzimanje od. */
	private int preuzimanjeOd;
	
	/** The preuzimanje do. */
	private int preuzimanjeDo;
	
	/** The preuzimanje vrijeme. */
	private int preuzimanjeVrijeme;
	
	/** The vrijeme pauza. */
	private int vrijemePauza;
	
	/** The preuzimanje pauza. */
	private long preuzimanjePauza;
	
	/** The tc. */
	private int tc;
	
	/** The vrijeme obrade. */
	private int vrijemeObrade;
	
	/** The stvarni brojac. */
	private int stvarniBrojac;
	
	/** The virtualni brojac. */
	private int virtualniBrojac;
	
	/** The korime. */
	private String korime;
	
	/** The lozinka. */
	private String lozinka;
	
	/** The os klijent. */
	private OSKlijent osKlijent;

	/** The t 1. */
	private int t1;

	/** The pbp. */
	PostavkeBazaPodataka pbp;

	/**
	 * Instantiates a new preuzimanje rasporeda aerodroma.
	 *
	 * @param pbp the pbp
	 */
	public PreuzimanjeRasporedaAerodroma(PostavkeBazaPodataka pbp) {
		this.pbp = pbp;
	}

	/**
	 * Start dretve.
	 */
	@Override
	public synchronized void start() {
		try {
			this.preuzimanjeOd = (int) (new java.text.SimpleDateFormat("dd.MM.yyyy")
					.parse(pbp.dajPostavku("preuzimanje.od")).getTime() / 1000);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		try {
			this.preuzimanjeDo = (int) (new java.text.SimpleDateFormat("dd.MM.yyyy")
					.parse(pbp.dajPostavku("preuzimanje.do")).getTime() / 1000);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		this.preuzimanjeVrijeme = Integer.parseInt(pbp.dajPostavku("preuzimanje.vrijeme"))*3600;
		this.vrijemePauza = Integer.parseInt(pbp.dajPostavku("preuzimanje.pauza"));
		this.tc = Integer.parseInt(pbp.dajPostavku("ciklus.vrijeme")) * 1000;
		this.vrijemeObrade = this.preuzimanjeOd;
		this.preuzimanjePauza =  Long.parseLong(pbp.dajPostavku("preuzimanje.pauza"));
		

		this.korime = pbp.dajPostavku("OpenSkyNetwork.korisnik");
		this.lozinka = pbp.dajPostavku("OpenSkyNetwork.lozinka");

		this.osKlijent = new OSKlijent(korime, lozinka);

		super.start();
	}

	/**
	 * Run dretve.
	 */
	@Override
	public void run() {
		List<Aerodrom> aerodromi = new ArrayList<>();

		AerodromPraceniDAO aerodromPraceniDAO = new AerodromPraceniDAO();

		while (this.vrijemeObrade < this.preuzimanjeDo) {
			aerodromi = aerodromPraceniDAO.dajAerodromeZaPratiti(pbp);
			t1 = (int) System.currentTimeMillis();

			for (Aerodrom a : aerodromi) {
				System.out.println("Polasci s aerodroma: " + a.getIcao());
				List<AvionLeti> avioniPolasci;
				try {
					avioniPolasci = osKlijent.getDepartures(a.getIcao(), this.preuzimanjeOd, this.preuzimanjeDo);
					if (avioniPolasci != null) {
						System.out.println("Broj letova: " + avioniPolasci.size());
						for (AvionLeti avion : avioniPolasci) {
							AerodromPolasciDAO aerodromPolasciDAO = new AerodromPolasciDAO();
							aerodromPolasciDAO.dodajPolazakAerodroma(pbp, avion);
							System.out.println(
									"Avion: " + avion.getIcao24() + " Odredište: " + avion.getEstArrivalAirport());
						}
					}
				} catch (NwtisRestIznimka e) {
					AerodromProblemiDAO aerodromProblemiDAO = new AerodromProblemiDAO();
					aerodromProblemiDAO.dodajProblem(pbp, a.getIcao(), e.getMessage());
				}
				System.out.println("Dolasci na aerodrom: " + a.getIcao());
				List<AvionLeti> avioniDolasci;
				try {
					avioniDolasci = osKlijent.getArrivals(a.getIcao(), this.preuzimanjeOd, this.preuzimanjeDo);
					if (avioniDolasci != null) {
						System.out.println("Broj letova: " + avioniDolasci.size());
						for (AvionLeti avion : avioniDolasci) {
							AerodromDolasciDAO aerodromDolasciDAO = new AerodromDolasciDAO();
							aerodromDolasciDAO.dodajDolazakAerodroma(pbp, avion);
							System.out.println(
									"Avion: " + avion.getIcao24() + " Odredište: " + avion.getEstDepartureAirport());
						}
					}
				}

				catch (NwtisRestIznimka e) {
					AerodromProblemiDAO aerodromProblemiDAO = new AerodromProblemiDAO();
					aerodromProblemiDAO.dodajProblem(pbp, a.getIcao(), e.getMessage());
				}
				try {
					sleep(this.preuzimanjePauza);
				} catch (InterruptedException e) {
					
				}
			}
			int te = (int) (System.currentTimeMillis()) - t1;

			long ck = Long.parseLong(pbp.dajPostavku("ciklus.korekcija"));
			long ts;
			this.vrijemeObrade = t1 + tc;
			if (te > tc) {
				int i = 2;
				do {
					ts = i * tc - te;
					i++;
				} while (ts < 0);
				this.stvarniBrojac++;
				this.virtualniBrojac += i;
			} else {
				ts = tc - te;
				this.stvarniBrojac++;
				this.virtualniBrojac++;
			}
			
			if(this.stvarniBrojac % ck == 0) {
				ts = (t1 + this.virtualniBrojac * tc) - Instant.now().toEpochMilli();
			}
			
			this.vrijemeObrade += this.preuzimanjeVrijeme;
			
			System.out.println("Stvarni brojac: " + this.stvarniBrojac);
			System.out.println("Virtualni brojac: " + this.virtualniBrojac);
			System.out.println("Spavanje bude: " + ts);
			
			try {
				sleep(ts);
			} catch (InterruptedException e) {
				
			}
		}
	}

	/**
	 * Interrupt dretve.
	 */
	@Override
	public void interrupt() {
		super.interrupt();
	}

}
