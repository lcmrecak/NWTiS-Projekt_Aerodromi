package org.foi.nwtis.lcmrecak.projekt.podaci;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.rest.klijenti.NwtisRestIznimka;


/**
 * Klasa AerodromProblemiDAO.
 */
public class AerodromProblemiDAO {
	
	/**
	 * Dodaj problem.
	 *
	 * @param Parametar PostavkeBazePodataka pbp
	 * @param Parametar icao tipa String
	 * @param Parametar opis tipa String
	 * @return vraća true ako je uspješno
	 */
	public boolean dodajProblem(PostavkeBazaPodataka pbp, String icao, String opis)
	{
		String url = pbp.getServerDatabase()+pbp.getUserDatabase();
		String bpkorisnik = pbp.getUserUsername();
		String bplozinka = pbp.getUserPassword();
		String sqlUpit = "INSERT INTO `AERODROMI_PROBLEMI` (`ident`, `description`, `stored`) VALUES (?, ?, NOW());";

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
		}
		

		try (Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);
			PreparedStatement statement = veza.prepareStatement(sqlUpit)){
			
			statement.setString(1, icao);
			statement.setString(2, opis.toString());

			statement.execute();
			
			return true;

		} catch (SQLException e) {
			return false;
		}
		
	}
	
	/**
	 * Daj sve probleme.
	 *
	 * @param pbp the pbp
	 * @return the array list
	 */
	public ArrayList<Problem> dajSveProbleme(PostavkeBazaPodataka pbp) {

		String url = pbp.getServerDatabase()+pbp.getUserDatabase();
		String bpkorisnik = pbp.getUserUsername();
		String bplozinka = pbp.getUserPassword();
		String sqlUpit = "SELECT * FROM `AERODROMI_PROBLEMI`;";

		ArrayList<Problem> problemi = new ArrayList<>();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
		
		}

		try (
                Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                Statement s = con.createStatement();
                ResultSet rs = s.executeQuery(sqlUpit)) {

           while (rs.next()) {
               Integer id = rs.getInt("id");
               String ident = rs.getString("ident");
               String description = rs.getString("description");
               String stored = rs.getString("stored");
               Problem p = new Problem(ident, description);

               problemi.add(p);
           }
           return problemi;

       } catch (SQLException ex) {

       }
		

		return problemi;
	}
	
	/**
	 * Obrisi probleme.
	 *
	 * @param pbp the pbp
	 * @param icao the icao
	 * @return true, if successful
	 */
	public boolean obrisiProbleme(PostavkeBazaPodataka pbp, String icao)
	{
		String url = pbp.getServerDatabase()+pbp.getUserDatabase();
		String bpkorisnik = pbp.getUserUsername();
		String bplozinka = pbp.getUserPassword();
		String sqlUpit = "DELETE FROM `AERODROMI_PROBLEMI` WHERE ident = ?";

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			
		}
		

		try (Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);
			PreparedStatement statement = veza.prepareStatement(sqlUpit)){
			
			statement.setString(1, icao);

			statement.execute();
			
			return true;

		} catch (SQLException e) {

			return false;
		}
		
	}

}
