package org.foi.nwtis.lcmrecak.projekt.podaci;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Klasa Problem.
 */
@AllArgsConstructor()
public class Problem {
	
	/**  ident. */
	private String ident;
	
	/**  opis. */
	private String description;
	
	/**
	 * Instanciranje novog Problema.
	 *
	 * @param Parametar ident
	 * @param Parametar opis
	 */
	public Problem(String ident, String description) {
		super();
		this.setIdent(ident);
		this.setDescription(description);
	}

	/**
	 * Dohvaćanje opisa.
	 *
	 * @return vraća opis
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Postavljanje opisa.
	 *
	 * @param Parametar opis
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Dohvaćanje identa.
	 *
	 * @return vraća ident
	 */
	public String getIdent() {
		return ident;
	}

	/**
	 * Postavljanje identa.
	 *
	 * @param Parametar ident
	 */
	public void setIdent(String ident) {
		this.ident = ident;
	}
	
}
