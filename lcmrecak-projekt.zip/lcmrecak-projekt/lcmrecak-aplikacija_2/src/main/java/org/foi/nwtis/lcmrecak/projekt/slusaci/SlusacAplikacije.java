package org.foi.nwtis.lcmrecak.projekt.slusaci;

import java.io.File;

import org.foi.nwtis.lcmrecak.projekt.dretve.PreuzimanjeRasporedaAerodroma;
import org.foi.nwtis.lcmrecak.vjezba_03.konfiguracije.NeispravnaKonfiguracija;
import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.KonfiguracijaBP;
import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

/**
 * Klasa SlusacAplikacije.
 */
@WebListener
public class SlusacAplikacije implements ServletContextListener {

	/** The konfig. */
	private PostavkeBazaPodataka konfig;
	
    /**
     * Konstruktor slusac aplikacije.
     */
    public SlusacAplikacije() {
       
    }

    /**
     * Inicijalizacija contexta.
     *
     * @param Parametar sce
     */
    @Override
	public void contextInitialized(ServletContextEvent sce) {
    	ServletContext context = sce.getServletContext();
    	String nazivDatoteke = context.getInitParameter("konfiguracija");
    	String putanja = context.getRealPath("/WEB-INF") + File.separator;
    	nazivDatoteke = putanja + nazivDatoteke;
    	
    	System.out.println(nazivDatoteke);
    	
    	konfig = new PostavkeBazaPodataka(nazivDatoteke);
    	try {
			konfig.ucitajKonfiguraciju();
		} catch (NeispravnaKonfiguracija e) {
			e.printStackTrace();
			return;
		}
    	
    	context.setAttribute("Postavke", konfig);
    	System.out.println("Postavke učitane!");
    	
    	PreuzimanjeRasporedaAerodroma pra = new PreuzimanjeRasporedaAerodroma(konfig);
    	pra.start();
    	
		ServletContextListener.super.contextInitialized(sce);
	}
    
	/**
	 * Context uništenje.
	 *
	 * @param Parametar sce
	 */
	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		ServletContext context = sce.getServletContext();
		context.removeAttribute("postavke");
		System.out.println("Postavke obrisane!");
		
		ServletContextListener.super.contextDestroyed(sce);
	}
    
}
