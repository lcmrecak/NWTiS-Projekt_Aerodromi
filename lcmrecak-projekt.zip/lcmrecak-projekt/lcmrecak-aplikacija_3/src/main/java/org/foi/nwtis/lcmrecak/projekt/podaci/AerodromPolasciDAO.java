package org.foi.nwtis.lcmrecak.projekt.podaci;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.rest.podaci.AvionLeti;


/**
 * Klasa AerodromPolasciDAO.
 */
public class AerodromPolasciDAO {
	
	/** The url. */
	private String url = "";
	
	/** The bpkorisnik. */
	private String bpkorisnik = "";
	
	/** The bplozinka. */
	private String bplozinka = "";

	/**
	 * Dodaj polazak aerodroma.
	 *
	 * @param pbp the pbp
	 * @param avioniPolasci the avioni polasci
	 * @return vraća true ako je uspješno
	 */
	public boolean dodajPolazakAerodroma(PostavkeBazaPodataka pbp, AvionLeti avioniPolasci) {
		String url = pbp.getServerDatabase() + pbp.getUserDatabase();
		String bpkorisnik = pbp.getUserUsername();
		String bplozinka = pbp.getUserPassword();
		String sqlUpit = "INSERT INTO `AERODROMI_POLASCI` (`icao24`, `firstSeen`, `estDepartureAirport`, `lastSeen`, "
				+ "`estArrivalAirport`, `callsign`, `estDepartureAirportHorizDistance`, `estDepartureAirportVertDistance`, "
				+ "`estArrivalAirportHorizDistance`, `estArrivalAirportVertDistance`, `departureAirportCandidatesCount`, "
				+ "`arrivalAirportCandidatesCount`, `stored`) VALUES " + "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW());";

		String icao24 = avioniPolasci.getIcao24();
		Integer firstSeen = avioniPolasci.getFirstSeen();
		String estDepartureAirport = avioniPolasci.getEstDepartureAirport();
		Integer lastSeen = avioniPolasci.getLastSeen();
		String estArrivalAirport = avioniPolasci.getEstArrivalAirport();
		String callsign = avioniPolasci.getCallsign();
		Integer estDepartureAirportHorizDistance = avioniPolasci.getEstDepartureAirportHorizDistance();
		Integer estAirportVertDistance = avioniPolasci.getEstDepartureAirportVertDistance();
		Integer estArrivalAirportHorizDistance = avioniPolasci.getEstArrivalAirportHorizDistance();
		Integer estArrivalAirportVertDistance = avioniPolasci.getEstArrivalAirportVertDistance();
		Integer departureAirportCandidatesCount = avioniPolasci.getDepartureAirportCandidatesCount();
		Integer arrivalAirportCandidatesCount = avioniPolasci.getArrivalAirportCandidatesCount();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			try (Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);
					PreparedStatement statement = veza.prepareStatement(sqlUpit)) {

				statement.setString(1, icao24);
				statement.setInt(2, firstSeen);
				statement.setString(3, estDepartureAirport);
				statement.setInt(4, lastSeen);
				statement.setString(5, estArrivalAirport);
				statement.setString(6, callsign);
				statement.setInt(7, estDepartureAirportHorizDistance);
				statement.setInt(8, estAirportVertDistance);
				statement.setInt(9, estArrivalAirportHorizDistance);
				statement.setInt(10, estArrivalAirportVertDistance);
				statement.setInt(11, departureAirportCandidatesCount);
				statement.setInt(12, arrivalAirportCandidatesCount);

				statement.execute();

				return true;

			} catch (SQLException e) {

				e.printStackTrace();
				return false;
			}
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return false;
		}

	}

	/**
	 * Daj polaske aerodroma.
	 *
	 * @param pbp the pbp
	 * @return vraća listu polazaka aerodroma
	 */
	public List<AvionLeti> dajPolaskeAerodroma(PostavkeBazaPodataka pbp) {
		vezaBP(pbp);

		List<AvionLeti> aerodromi = new ArrayList<>();

		try {
			Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);

			Statement statement = veza.createStatement();

			String sqlUpit = "SELECT * FROM AERODROMI_POLASCI";

			ResultSet result = statement.executeQuery(sqlUpit);

			while (result.next()) {

				AvionLeti al = new AvionLeti(result.getString(2), result.getInt(3), result.getString(4),
						result.getInt(5), result.getString(6), result.getString(7), result.getInt(8), result.getInt(9),
						result.getInt(10), result.getInt(11), result.getInt(12), result.getInt(13));

				aerodromi.add(al);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return aerodromi;
	}
	
	/**
	 * Kreiranje veze na bazu.
	 *
	 * @param pbp the pbp
	 */
	public void vezaBP(PostavkeBazaPodataka pbp) {
		url = pbp.getServerDatabase()+pbp.getUserDatabase();
		bpkorisnik = pbp.getUserUsername();
		bplozinka = pbp.getUserPassword();
		
		String driver = pbp.dajPostavku("jdbc.mysql");

		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e1) {

			e1.printStackTrace();
		}
	}

}
