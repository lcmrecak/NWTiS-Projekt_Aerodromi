package org.foi.nwtis.lcmrecak.projekt.podaci;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.podaci.Aerodrom;
import org.foi.nwtis.podaci.Korisnik;
import org.foi.nwtis.rest.podaci.Lokacija;

// TODO: Auto-generated Javadoc
/**
 * Klasa AerodromPraceniDAO.
 */
public class AerodromPraceniDAO {
	
	/** The url. */
	private String url = "";
	
	/** The bpkorisnik. */
	private String bpkorisnik = "";
	
	/** The bplozinka. */
	private String bplozinka = "";

	/**
	 * Daj sve aerodrome.
	 *
	 * @param pbp the pbp
	 * @return vraća listu svih aerodroma
	 */
	public ArrayList<Aerodrom> dajSveAerodrome(PostavkeBazaPodataka pbp) {
		vezaBP(pbp);

		ArrayList<Aerodrom> aerodromi = new ArrayList<>();

		try {
			Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);

			Statement statement = veza.createStatement();

			String sqlUpit = "SELECT ident, name, iso_country, coordinates FROM airports;";

			ResultSet result = statement.executeQuery(sqlUpit);

			while (result.next()) {

				String[] podjela = result.getString("coordinates").split(", ");

				Aerodrom ad = new Aerodrom(result.getString("ident"), result.getString("name"),
						result.getString("iso_country"), new Lokacija(podjela[0], podjela[1]));

				aerodromi.add(ad);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		

		return aerodromi;
	}
	
	/**
	 * Daj aerodrome za pratiti.
	 *
	 * @param pbp the pbp
	 * @return vraća listu aerodroma za pratiti
	 */
	public ArrayList<Aerodrom> dajAerodromeZaPratiti(PostavkeBazaPodataka pbp){
		vezaBP(pbp);

		ArrayList<Aerodrom> aerodromi = new ArrayList<>();

		try {
			Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);

			Statement statement = veza.createStatement();

			String sqlUpit = "SELECT ap.ident, a.name, a.iso_country, a.coordinates FROM AERODROMI_PRACENI ap, airports a WHERE ap.ident=a.ident;";

			ResultSet result = statement.executeQuery(sqlUpit);

			while (result.next()) {

				String[] podjela = result.getString("coordinates").split(", ");

				Aerodrom ad = new Aerodrom(result.getString("ident"), result.getString("name"),
						result.getString("iso_country"), new Lokacija(podjela[0], podjela[1]));

				aerodromi.add(ad);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		

		return aerodromi;
	}
	
	/**
	 * Daj aerodrom.
	 *
	 * @param aerodrom the aerodrom
	 * @param pbp the pbp
	 * @return vraća true ako je uspješna
	 */
	public boolean dodajAerodrom(String aerodrom, PostavkeBazaPodataka pbp){
		vezaBP(pbp);
		String sqlUpit = "INSERT INTO `AERODROMI_PRACENI` (`ident`, `stored`) VALUES (?, now());";

		try (Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);
			PreparedStatement statement = veza.prepareStatement(sqlUpit)){
			
			statement.setString(1, aerodrom);

			statement.execute();
			
			return true;

		} catch (SQLException e) {

			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * Kreiranje veze na bazu.
	 *
	 * @param pbp the pbp
	 */
	public void vezaBP(PostavkeBazaPodataka pbp) {
		url = pbp.getServerDatabase()+pbp.getUserDatabase();
		bpkorisnik = pbp.getUserUsername();
		bplozinka = pbp.getUserPassword();
		
		String driver = pbp.dajPostavku("jdbc.mysql");

		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e1) {

			e1.printStackTrace();
		}
	}

}
