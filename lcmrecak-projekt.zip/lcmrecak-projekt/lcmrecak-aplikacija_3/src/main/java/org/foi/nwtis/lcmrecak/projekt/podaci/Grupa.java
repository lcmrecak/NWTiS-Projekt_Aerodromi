package org.foi.nwtis.lcmrecak.projekt.podaci;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;


/**
 * Klasa Grupa.
 */
public class Grupa implements Serializable{

	/**
	 * Instancira novu klasu Grupa.
	 *
	 * @param grupa the grupa
	 * @param naziv the naziv
	 */
	public Grupa(String grupa, String naziv) {
		super();
		this.grupa = grupa;
		this.naziv = naziv;
	}
	
	/** Getter i setter grupa. */
	@Getter
	@Setter
	public String grupa;
	
	/** Getter i setter naziv. */
	@Getter
	@Setter
	public String naziv;

}
