package org.foi.nwtis.lcmrecak.projekt.podaci;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.podaci.Korisnik;

/**
 * Klasa KorisniciDAO.
 */
public class KorisniciDAO {
	
	/** The url. */
	private String url = "";
	
	/** The bpkorisnik. */
	private String bpkorisnik = "";
	
	/** The bplozinka. */
	private String bplozinka = "";

	/**
	 * Daj sve korisnike.
	 *
	 * @param pbp the pbp
	 * @return the array list
	 */
	public ArrayList<Korisnik> dajSveKorisnike(PostavkeBazaPodataka pbp) {
		vezaBP(pbp);
		ArrayList<Korisnik> korisnici = new ArrayList<>();

		try {
			Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);

			Statement statement = veza.createStatement();

			String sqlUpit = "SELECT * FROM `korisnici`;";

			ResultSet result = statement.executeQuery(sqlUpit);

			while (result.next()) {

				Korisnik kor = new Korisnik(result.getString("korisnik"), result.getString("ime"),
						result.getString("prezime"), result.getString("lozinka"), result.getString("email"));

				korisnici.add(kor);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return korisnici;
	}

	/**
	 * Dodaj korisnika.
	 *
	 * @param korisnik the korisnik
	 * @param pbp the pbp
	 * @return true, if successful
	 */
	public boolean dodajKorisnika(Korisnik korisnik, PostavkeBazaPodataka pbp) {
		vezaBP(pbp);
		String sqlUpit = "INSERT INTO `korisnici` (`korisnik`, `ime`, `prezime`, `lozinka`, `email`) VALUES (?, ?, ?, ?, ?);";

		try (Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);
				PreparedStatement statement = veza.prepareStatement(sqlUpit)) {

			statement.setString(1, korisnik.getKorIme().toString());
			statement.setString(2, korisnik.getIme().toString());
			statement.setString(3, korisnik.getPrezime().toString());
			statement.setString(4, korisnik.getLozinka().toString());
			statement.setString(5, korisnik.getEmail().toString());

			statement.execute();

			return true;

		} catch (SQLException e) {

			e.printStackTrace();
			return false;
		}
	}

	/**
	 * Daj grupe korisnika.
	 *
	 * @param korisnik the korisnik
	 * @param pbp the pbp
	 * @return the array list
	 */
	public ArrayList<Grupa> dajGrupeKorisnika(String korisnik, PostavkeBazaPodataka pbp) {
		vezaBP(pbp);
		ArrayList<Grupa> grupe = new ArrayList<>();

		try {
			Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);

			Statement statement = veza.createStatement();

			String sqlUpit = "SELECT uloge.grupa, grupe.naziv FROM `uloge` INNER JOIN grupe ON uloge.grupa=grupe.grupa WHERE uloge.korisnik = \"" + korisnik + "\" ;";

			ResultSet result = statement.executeQuery(sqlUpit);

			while (result.next()) {

				Grupa gr = new Grupa(result.getString("grupa"), result.getString("naziv"));

				grupe.add(gr);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return grupe;
	}

	/**
	 * Provjera zetona.
	 *
	 * @param zeton the zeton
	 * @param korisnik the korisnik
	 * @param pbp the pbp
	 * @return the zeton
	 */
	public Zeton provjeraZetona(int zeton, String korisnik, PostavkeBazaPodataka pbp) {
		vezaBP(pbp);
		Zeton z = null;
		boolean vrijedi = false;

		try {
			Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);

			Statement statement = veza.createStatement();

			String sqlUpit = "SELECT korisnik, vrijeme, status FROM `zeton` WHERE id = " + zeton;

			ResultSet result = statement.executeQuery(sqlUpit);
			if (result.isBeforeFirst()) {
				result.next();
				z = new Zeton(zeton, result.getString("korisnik"), result.getLong("vrijeme"), result.getInt("status"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return z;
	}

	/**
	 * Kreiranje veze na bazu.
	 *
	 * @param pbp the pbp
	 */
	public void vezaBP(PostavkeBazaPodataka pbp) {
		url = pbp.getServerDatabase() + pbp.getUserDatabase();
		bpkorisnik = pbp.getUserUsername();
		bplozinka = pbp.getUserPassword();

		String driver = pbp.dajPostavku("jdbc.mysql");

		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e1) {

			e1.printStackTrace();
		}
	}
}
