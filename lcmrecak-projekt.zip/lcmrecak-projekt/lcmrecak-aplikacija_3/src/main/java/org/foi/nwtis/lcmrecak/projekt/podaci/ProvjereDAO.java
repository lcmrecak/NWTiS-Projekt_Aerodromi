package org.foi.nwtis.lcmrecak.projekt.podaci;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.podaci.Korisnik;

import jakarta.ws.rs.core.Response;

/**
 * Klasa ProvjereDAO.
 */
public class ProvjereDAO {
	
	/** The url. */
	private String url = "";
	
	/** The bpkorisnik. */
	private String bpkorisnik = "";
	
	/** The bplozinka. */
	private String bplozinka = "";

	/**
	 * Provjera autentikacija.
	 *
	 * @param korisnik the korisnik
	 * @param lozinka the lozinka
	 * @param pbp the pbp
	 * @return the string
	 */
	public String provjeraAutentikacija(String korisnik, String lozinka, PostavkeBazaPodataka pbp) {
		String odgovor = "";
		vezaBP(pbp);
		boolean provjeraKorisnika = false;

		ArrayList<Korisnik> korisnici = new ArrayList<>();
		
		korisnici = dajSveKorisnike(pbp);
		
		for (Korisnik k : korisnici) {
			if (k.getKorIme().compareTo(korisnik) == 0 && k.getLozinka().compareTo(lozinka)==0) {
				provjeraKorisnika = true;
			}
		}

		if (provjeraKorisnika) {
			String vrijeme = dodajZeton(korisnik, pbp);

			try {
				Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);

				Statement statement = veza.createStatement();

				String sqlUpit = "SELECT id FROM `zeton` WHERE korisnik = \"" + korisnik
						+ "\" ORDER BY id DESC LIMIT 1 ;";

				ResultSet result = statement.executeQuery(sqlUpit);
				result.next();
				odgovor = "zeton: " + result.getString("id") + ", vrijeme: " + vrijeme;

			} catch (SQLException e) {

				e.printStackTrace();
				odgovor = "401";
			}
		}
		else odgovor = "401";

		return odgovor;
	}


	/**
	 * Dodaj zeton.
	 *
	 * @param korisnik the korisnik
	 * @param pbp the pbp
	 * @return the string
	 */
	private String dodajZeton(String korisnik, PostavkeBazaPodataka pbp) {
		String odgovor = "";
		vezaBP(pbp);

		Long vrijeme = (long) (System.currentTimeMillis() / 1000 + Integer.parseInt(pbp.dajPostavku("zeton.trajanje")));

		String upit = "INSERT INTO `zeton` (`korisnik`, `vrijeme`) VALUES (?, ?) ";

		try (Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);
				PreparedStatement statement = veza.prepareStatement(upit)) {

			statement.setString(1, korisnik);
			statement.setLong(2, vrijeme);

			statement.execute();

			return odgovor = vrijeme.toString();

		} catch (SQLException e) {

			e.printStackTrace();
			return odgovor = "401 - ZETON NIJE DODAN";
		}
	}

	/**
	 * Provjera zetona.
	 *
	 * @param zeton the zeton
	 * @param pbp the pbp
	 * @return the zeton
	 */
	public Zeton provjeraZetona(int zeton, PostavkeBazaPodataka pbp) {
		vezaBP(pbp);
		Zeton z = null;

		try {
			Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);

			Statement statement = veza.createStatement();

			String sqlUpit = "SELECT korisnik, vrijeme, status FROM `zeton` WHERE id = " + zeton;

			ResultSet result = statement.executeQuery(sqlUpit);
			result.next();
			z = new Zeton(zeton, result.getString("korisnik"), result.getInt("vrijeme"), result.getInt("status"));

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return z;
	}

	/**
	 * Update zetona.
	 *
	 * @param zeton the zeton
	 * @param pbp the pbp
	 * @return the zeton
	 */
	public Zeton updateZetona(int zeton, PostavkeBazaPodataka pbp) {
		vezaBP(pbp);
		Zeton z = new Zeton(0,"",0,0);
		String sqlUpit = "UPDATE `zeton` SET `status` = '0' WHERE `zeton`.`id` = " + zeton;
		String sqlUpit1 = "SELECT korisnik, vrijeme, status FROM `zeton` WHERE id = " + zeton;

		try (Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);
				PreparedStatement statement = veza.prepareStatement(sqlUpit)) {

			statement.execute();

			ResultSet result = statement.executeQuery(sqlUpit1);
			result.next();
			z = new Zeton(zeton, result.getString("korisnik"), result.getInt("vrijeme"), result.getInt("status"));


		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return z;
	}

	/**
	 * Brisanje zetona.
	 *
	 * @param korisnik the korisnik
	 * @param pbp the pbp
	 * @return true, if successful
	 */
	public boolean brisanjeZetona(String korisnik, PostavkeBazaPodataka pbp) {
		vezaBP(pbp);
		boolean azurirano = false;
		String sqlUpit = "UPDATE `zeton` SET `status` = '0' WHERE `zeton`.`korisnik` = \"" + korisnik + "\"; ";

		boolean postoji = provjeraAktivnogZetona(korisnik, pbp);

		if (postoji) {

			try (Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);
					PreparedStatement statement = veza.prepareStatement(sqlUpit)) {

				statement.execute();
				azurirano = true;

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return azurirano;
	}

	/**
	 * Provjera aktivnog zetona.
	 *
	 * @param korisnik the korisnik
	 * @param pbp the pbp
	 * @return true, if successful
	 */
	private boolean provjeraAktivnogZetona(String korisnik, PostavkeBazaPodataka pbp) {
		vezaBP(pbp);
		boolean admin = false;

		try {
			Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);

			Statement statement = veza.createStatement();

			String sqlUpit = "SELECT id, vrijeme, status FROM `zeton` WHERE korisnik = \"" + korisnik + "\" AND status = 1";

			ResultSet result = statement.executeQuery(sqlUpit);
			result.next();
			Zeton z = new Zeton(result.getInt("id"), korisnik, result.getInt("vrijeme"), result.getInt("status"));
			
			if(z.status == 1) admin = true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return admin;

	}

	/**
	 * Admin provjera.
	 *
	 * @param korisnik the korisnik
	 * @param pbp the pbp
	 * @return true, if successful
	 */
	public boolean adminProvjera(String korisnik, PostavkeBazaPodataka pbp) {
		vezaBP(pbp);
		boolean admin = false;
		try {
			Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);

			Statement statement = veza.createStatement();

			String sqlUpit = "SELECT grupa FROM `uloge` WHERE korisnik = \"" + korisnik + "\" ";
			
			System.out.println("UPIT: " + sqlUpit);
			

			ResultSet result = statement.executeQuery(sqlUpit);
			result.next();
			System.out.println("Dohvacena grupa: " + result.getString("grupa"));

			if (result.getString("grupa").equals("admin"))
				admin = true;
			else
				admin = false;

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return admin;
	}
	
	/**
	 * Daj sve korisnike.
	 *
	 * @param pbp the pbp
	 * @return the array list
	 */
	public ArrayList<Korisnik> dajSveKorisnike(PostavkeBazaPodataka pbp) {
		vezaBP(pbp);
		ArrayList<Korisnik> korisnici = new ArrayList<>();

		try {
			Connection veza = DriverManager.getConnection(url, bpkorisnik, bplozinka);

			Statement statement = veza.createStatement();

			String sqlUpit = "SELECT * FROM `korisnici`;";

			ResultSet result = statement.executeQuery(sqlUpit);
			result.next();
			while (result.next()) {

				Korisnik kor = new Korisnik(result.getString("korisnik"), result.getString("ime"), result.getString("prezime"), result.getString("lozinka"),result.getString("email"));

				korisnici.add(kor);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		

		return korisnici;
	}

	/**
	 * Kreiranje veze na bazu.
	 *
	 * @param pbp the pbp
	 */
	public void vezaBP(PostavkeBazaPodataka pbp) {
		url = pbp.getServerDatabase() + pbp.getUserDatabase();
		bpkorisnik = pbp.getUserUsername();
		bplozinka = pbp.getUserPassword();

		String driver = pbp.dajPostavku("jdbc.mysql");

		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e1) {

			e1.printStackTrace();
		}
	}
}
