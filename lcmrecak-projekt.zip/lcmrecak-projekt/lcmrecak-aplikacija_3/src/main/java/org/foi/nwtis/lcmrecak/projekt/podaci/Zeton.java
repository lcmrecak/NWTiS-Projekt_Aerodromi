package org.foi.nwtis.lcmrecak.projekt.podaci;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

// TODO: Auto-generated Javadoc
/**
 * The Class Zeton.
 */
public class Zeton implements Serializable{

	/**
	 * Instanciranje klasezeton.
	 *
	 * @param id the id
	 * @param korisnik the korisnik
	 * @param vrijeme the vrijeme
	 * @param status the status
	 */
	public Zeton(int id, String korisnik, long vrijeme, int status) {
		super();
		this.id = id;
		this.korisnik = korisnik;
		this.vrijeme = vrijeme;
		this.status = status;
	}
	
	/** Getter i setter id. */
	@Getter
	@Setter
	public int id;
	
	/** Getter i setter korisnik. */
	@Getter
	@Setter
	public String korisnik;
	
	/** The vrijeme. */
	@Getter
	@Setter
	public long vrijeme;
	
	/** The status. */
	@Getter
	@Setter
	public int status;
	
}
