package org.foi.nwtis.lcmrecak.projekt.rest;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.foi.nwtis.lcmrecak.projekt.podaci.AerodromDolasciDAO;
import org.foi.nwtis.lcmrecak.projekt.podaci.AerodromPolasciDAO;
import org.foi.nwtis.lcmrecak.projekt.podaci.AerodromPraceniDAO;
import org.foi.nwtis.lcmrecak.projekt.podaci.KorisniciDAO;
import org.foi.nwtis.lcmrecak.projekt.podaci.Zeton;
import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.podaci.Aerodrom;
import org.foi.nwtis.rest.podaci.AvionLeti;

import com.google.gson.Gson;
import com.google.protobuf.TextFormat.ParseException;

import jakarta.inject.Inject;
import jakarta.servlet.ServletContext;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

/**
 * Klasa RestAerodromi.
 */
@Path("aerodromi")
public class RestAerodromi {

	/** The pbp. */
	PostavkeBazaPodataka pbp;
	
	/** The context. */
	@Inject
	ServletContext context;

	/**
	 * Instancira klasu RestAerodromi.
	 *
	 * @param context the context
	 */
	@Inject
	public RestAerodromi(ServletContext context) {
		this.context = context;
		this.pbp = (PostavkeBazaPodataka) context.getAttribute("postavke");
	}

	/**
	 * Daj sve aerodrome.
	 *
	 * @param korisnik the korisnik
	 * @param zeton the zeton
	 * @return vraća odgovor sa svim aerodromima
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	public Response dajSveAerodrome(@HeaderParam("korisnik") String korisnik, @HeaderParam("zeton") int zeton) {
		Response odgovor = null;
		ArrayList<Aerodrom> aerodromi = new ArrayList<>();

		KorisniciDAO korisniciDAO = new KorisniciDAO();
		AerodromPraceniDAO aerodromPraceniDAO = new AerodromPraceniDAO();
		aerodromi = aerodromPraceniDAO.dajAerodromeZaPratiti(pbp);

		Zeton z = korisniciDAO.provjeraZetona(zeton, korisnik, pbp);

		if (z == null) {
			odgovor = Response.status(Response.Status.NOT_FOUND).entity("Token ne postoji!").build();
		} else if (z.korisnik.equals(korisnik) && z.status == 1) {
			if (aerodromi != null) {
				odgovor = Response.status(Response.Status.OK).entity(aerodromi).build();
			} else {
				odgovor = Response.status(Response.Status.NOT_FOUND).entity("Nema aerodroma.").build();
			}
		} else if (!z.korisnik.equals(korisnik)) {
			odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("Zeton ne pripada korisniku").build();
		} else if (z.status == 0 || z.vrijeme < LocalDateTime.now().toLocalTime().toSecondOfDay()) {
			odgovor = Response.status(Response.Status.REQUEST_TIMEOUT).entity("Zeton nije aktivan ili je istekao")
					.build();
		}

		return odgovor;
	}

	/**
	 * Dodaj aerodrom za pratiti.
	 *
	 * @param korisnik the korisnik
	 * @param zeton the zeton
	 * @param icao the icao
	 * @return vraća odgovor
	 */
	@POST
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	public Response dodajAerodromZaPratiti(@HeaderParam("korisnik") String korisnik, @HeaderParam("zeton") int zeton, String icao) {
		Response odgovor = null;
		boolean postoji = false;

		AerodromPraceniDAO aerodromPraceniDAO = new AerodromPraceniDAO();
		KorisniciDAO korisniciDAO = new KorisniciDAO();
		Zeton z = korisniciDAO.provjeraZetona(zeton, korisnik, pbp);
		
		System.out.println("ICAO primljeni: " + icao);

		ArrayList<Aerodrom> aerodromi = aerodromPraceniDAO.dajAerodromeZaPratiti(pbp);

		for (Aerodrom a : aerodromi) {
			if (a.getIcao().equals(icao)) {
				postoji = true;
				odgovor = Response.status(Response.Status.FORBIDDEN).entity("Aerodrom već postoji").build();
			}
		}

		if (z == null) {
			odgovor = Response.status(Response.Status.NOT_FOUND).entity("Token ne postoji!").build();
		} else if (z.korisnik.equals(korisnik) && z.status == 1 && postoji == false) {
			boolean dodaj = aerodromPraceniDAO.dodajAerodrom(icao, pbp);
			if (dodaj)
				odgovor = Response.status(Response.Status.OK).entity("Aerodrom dodan").build();
			else
				odgovor = Response.status(Response.Status.NOT_FOUND).entity("Aerodrom nije dodan").build();
		} else if (!z.korisnik.equals(korisnik)) {
			odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("Zeton ne pripada korisniku").build();
		} else if (z.status == 0 || z.vrijeme < LocalDateTime.now().toLocalTime().toSecondOfDay()) {
			odgovor = Response.status(Response.Status.REQUEST_TIMEOUT).entity("Zeton nije aktivan ili je istekao")
					.build();
		}

		return odgovor;
	}

	/**
	 * Daj aerodrom.
	 *
	 * @param korisnik the korisnik
	 * @param zeton the zeton
	 * @param icao the icao
	 * @return vraća odgovor sa traženim aerodromom
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("{icao}")
	public Response dajAerodrom(@HeaderParam("korisnik") String korisnik, @HeaderParam("zeton") int zeton,
			@PathParam("icao") String icao) {
		Response odgovor = null;

		ArrayList<Aerodrom> aerodromi = new ArrayList<>();
		System.out.println("Dobijem: " + korisnik + " " + zeton + " " + icao);

		AerodromPraceniDAO aerodromPraceniDAO = new AerodromPraceniDAO();
		KorisniciDAO korisniciDAO = new KorisniciDAO();
		Zeton z = korisniciDAO.provjeraZetona(zeton, korisnik, pbp);

		aerodromi = aerodromPraceniDAO.dajSveAerodrome(pbp);

		if (z == null) {
			odgovor = Response.status(Response.Status.NOT_FOUND).entity("Token ne postoji!").build();
		} else if (z.korisnik.equals(korisnik) && z.status == 1) {
			for (Aerodrom a : aerodromi) {
				if (a.getIcao().compareTo(icao) == 0) {
					System.out.println("NASEL SAM GA: " + a.getIcao());
					odgovor = Response.status(Response.Status.OK).entity(a).build();
					break;
				}
			}
		} else if (!z.korisnik.equals(korisnik)) {
			odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("Zeton ne pripada korisniku").build();
		} else if (z.status == 0 || z.vrijeme < LocalDateTime.now().toLocalTime().toSecondOfDay()) {
			odgovor = Response.status(Response.Status.REQUEST_TIMEOUT).entity("Zeton nije aktivan ili je istekao")
					.build();
		}

		return odgovor;
	}

	/**
	 * Daj polaske aerodrome.
	 *
	 * @param korisnik the korisnik
	 * @param zeton the zeton
	 * @param icao the icao
	 * @param vrsta the vrsta
	 * @param vrijemeOd the vrijeme od
	 * @param vrijemeDo the vrijeme do
	 * @return vraća odgovor sa polascima traženog aerodroma
	 * @throws ParseException the parse exception
	 * @throws ParseException the parse exception
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("{icao}/polasci")
	public Response dajPolaskeAerodoma(@HeaderParam("korisnik") String korisnik, @HeaderParam("zeton") int zeton,
			@PathParam("icao") String icao, @QueryParam("vrsta") int vrsta, @QueryParam("od") String vrijemeOd,
			@QueryParam("do") String vrijemeDo) throws ParseException, java.text.ParseException {
		Response odgovor = null;

		List<AvionLeti> avionPolasci;
		List<AvionLeti> avionPolasciVrijeme = new ArrayList<>();

		KorisniciDAO korisniciDAO = new KorisniciDAO();
		Zeton z = korisniciDAO.provjeraZetona(zeton, korisnik, pbp);
		AerodromPolasciDAO aerodromPolasciDAO = new AerodromPolasciDAO();

		System.out.println("Dobije: " + vrsta + " " + vrijemeOd + " " + vrijemeDo);

		if (z == null) {
			odgovor = Response.status(Response.Status.NOT_FOUND).entity("Token ne postoji!").build();
		} else if (z.korisnik.equals(korisnik) && z.status == 1) {
			if (vrsta == 0) {
				SimpleDateFormat formatter1 = new SimpleDateFormat("dd.MM.yyyy");
				Date vrijemeOd0 = formatter1.parse(vrijemeOd);
				Date vrijemeDo0 = formatter1.parse(vrijemeDo);

				avionPolasci = aerodromPolasciDAO.dajPolaskeAerodroma(pbp);

				for (AvionLeti a : avionPolasci) {
					long lastSeen = (long) a.getLastSeen() * 1000;
					String lastSeenString = new java.text.SimpleDateFormat("dd.MM.yyyy")
							.format(new java.util.Date(lastSeen));
					Date lastSeenDatum = formatter1.parse(lastSeenString);
					if (lastSeenDatum.after(vrijemeOd0) && lastSeenDatum.before(vrijemeDo0)) {
						avionPolasciVrijeme.add(a);
					}
				}
			}
			if (vrsta == 1) {
				long vrijemeOd1 = Long.parseLong(vrijemeOd);
				long vrijemeDo1 = Long.parseLong(vrijemeDo);

				avionPolasci = aerodromPolasciDAO.dajPolaskeAerodroma(pbp);

				for (AvionLeti a : avionPolasci) {
					long lastSeen = (long) a.getLastSeen();
					System.out.println("Dobije: " + vrijemeOd1 + " / " + lastSeen + " / " + vrijemeDo1);
					if (lastSeen >= vrijemeOd1 && lastSeen <= vrijemeDo1) {
						avionPolasciVrijeme.add(a);
					}
				}
			}
			odgovor = Response.status(Response.Status.OK).entity(avionPolasciVrijeme).build();
		} else if (!z.korisnik.equals(korisnik)) {
			odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("Zeton ne pripada korisniku").build();
		} else if (z.status == 0 || z.vrijeme < LocalDateTime.now().toLocalTime().toSecondOfDay()) {
			odgovor = Response.status(Response.Status.REQUEST_TIMEOUT).entity("Zeton nije aktivan ili je istekao")
					.build();
		}
		return odgovor;
	}

	/**
	 * Daj dolaske aerodrome.
	 *
	 * @param korisnik the korisnik
	 * @param zeton the zeton
	 * @param icao the icao
	 * @param vrsta the vrsta
	 * @param vrijemeOd the vrijeme od
	 * @param vrijemeDo the vrijeme do
	 * @return vraća odgovor sa dolascima traženog aerodroma
	 * @throws ParseException the parse exception
	 * @throws ParseException the parse exception
	 */

	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("{icao}/dolasci")
	public Response dajDolaskeAerodoma(@HeaderParam("korisnik") String korisnik, @HeaderParam("zeton") int zeton,
			@PathParam("icao") String icao, @QueryParam("vrsta") int vrsta, @QueryParam("od") String vrijemeOd,
			@QueryParam("do") String vrijemeDo) throws ParseException, java.text.ParseException {
		Response odgovor = null;

		List<AvionLeti> avionDolasci;
		List<AvionLeti> avionDolasciVrijeme = new ArrayList<>();

		KorisniciDAO korisniciDAO = new KorisniciDAO();
		Zeton z = korisniciDAO.provjeraZetona(zeton, korisnik, pbp);
		AerodromDolasciDAO aerodromDolasciDAO = new AerodromDolasciDAO();

		if (z == null) {
			odgovor = Response.status(Response.Status.NOT_FOUND).entity("Token ne postoji!").build();
		} else if (z.korisnik.equals(korisnik) && z.status == 1) {
			if (vrsta == 0) {
				SimpleDateFormat formatter1 = new SimpleDateFormat("dd.MM.yyyy");
				Date vrijemeOd0 = formatter1.parse(vrijemeOd);
				Date vrijemeDo0 = formatter1.parse(vrijemeDo);

				avionDolasci = aerodromDolasciDAO.dajDolaskeAerodroma(pbp);

				for (AvionLeti a : avionDolasci) {
					long lastSeen = (long) a.getLastSeen() * 1000;
					String lastSeenString = new java.text.SimpleDateFormat("dd.MM.yyyy")
							.format(new java.util.Date(lastSeen));
					Date lastSeenDatum = formatter1.parse(lastSeenString);

					if (lastSeenDatum.after(vrijemeOd0) && lastSeenDatum.before(vrijemeDo0)) {
						avionDolasciVrijeme.add(a);
					}
				}
			}
			if (vrsta == 1) {
				long vrijemeOd1 = new java.text.SimpleDateFormat("dd.MM.yyyy").parse(vrijemeOd).getTime() / 1000;
				long vrijemeDo1 = new java.text.SimpleDateFormat("dd.MM.yyyy").parse(vrijemeDo).getTime() / 1000;

				avionDolasci = aerodromDolasciDAO.dajDolaskeAerodroma(pbp);

				for (AvionLeti a : avionDolasci) {
					long lastSeen = (long) a.getLastSeen();

					if (lastSeen >= vrijemeOd1 && lastSeen <= vrijemeDo1) {
						avionDolasciVrijeme.add(a);
					}
				}
			}
			odgovor = Response.status(Response.Status.OK).entity(avionDolasciVrijeme).build();
		} else if (!z.korisnik.equals(korisnik)) {
			odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("Zeton ne pripada korisniku").build();
		} else if (z.status == 0 || z.vrijeme < LocalDateTime.now().toLocalTime().toSecondOfDay()) {
			odgovor = Response.status(Response.Status.REQUEST_TIMEOUT).entity("Zeton nije aktivan ili je istekao")
					.build();
		}
		return odgovor;
	}

	/**
	 * Daj udaljenost.
	 *
	 * @param korisnik the korisnik
	 * @param zeton the zeton
	 * @param icao1 the icao 1
	 * @param icao2 the icao 2
	 * @return the response
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("{icao1}/{icao2}")
	public Response dajUdaljenost(@HeaderParam("korisnik") String korisnik, @HeaderParam("zeton") int zeton,
			@PathParam("icao1") String icao1, @PathParam("icao2") String icao2) {
		Response odgovor = null;
		String greska = "";
		String povratniOdgovor = "";
		String[] udaljenost = null;

		KorisniciDAO korisniciDAO = new KorisniciDAO();
		Zeton z = korisniciDAO.provjeraZetona(zeton, korisnik, pbp);

		String komanda = "DISTANCE " + icao1 + " " + icao2;

		if (z == null) {
			odgovor = Response.status(Response.Status.NOT_FOUND).entity("Token ne postoji!").build();
		} else if (z.korisnik.equals(korisnik) && z.status == 1) {
			try (Socket veza = new Socket(pbp.dajPostavku("adresa.servera"), Integer.parseInt(pbp.dajPostavku("port")));
					InputStream is = veza.getInputStream();
					OutputStream os = veza.getOutputStream();
					OutputStreamWriter osw = new OutputStreamWriter(os)) {

				osw.write(komanda);
				osw.flush();
				veza.shutdownOutput();

				StringBuilder tekst = new StringBuilder();
				while (true) {
					int i = is.read();
					if (i == -1) {
						break;
					}
					tekst.append((char) i);
				}
				veza.shutdownInput();
				veza.close();
				
				povratniOdgovor = tekst.toString();
				udaljenost = tekst.toString().split(" ");

				if (udaljenost[0].equals("OK")) {
					povratniOdgovor = "udaljenost: " + udaljenost[1];
					System.out.println("Povratni: " + tekst.toString());
				}

			} catch (NumberFormatException | IOException e) {

				odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("GRESKA Server ne radi").build();
			}
			if (udaljenost[0].equals("OK")) {
				odgovor = Response.status(Response.Status.OK).entity(povratniOdgovor).build();
			}
			else if(udaljenost[0].equals("ERROR")) {
				odgovor = Response.status(Response.Status.BAD_REQUEST).entity(povratniOdgovor).build();
			}
		} else if (!z.korisnik.equals(korisnik)) {
			odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("Zeton ne pripada korisniku").build();
		} else if (z.status == 0 || z.vrijeme < LocalDateTime.now().toLocalTime().toSecondOfDay()) {
			odgovor = Response.status(Response.Status.REQUEST_TIMEOUT).entity("Zeton nije aktivan ili je istekao")
					.build();
		}
		return odgovor;
	}

}
