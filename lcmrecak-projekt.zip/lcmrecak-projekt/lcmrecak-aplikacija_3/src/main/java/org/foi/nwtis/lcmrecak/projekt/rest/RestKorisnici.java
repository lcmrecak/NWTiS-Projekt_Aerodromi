package org.foi.nwtis.lcmrecak.projekt.rest;

import java.time.LocalDateTime;
import java.util.ArrayList;

import org.foi.nwtis.lcmrecak.projekt.podaci.Grupa;
import org.foi.nwtis.lcmrecak.projekt.podaci.KorisniciDAO;
import org.foi.nwtis.lcmrecak.projekt.podaci.Zeton;
import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.podaci.Korisnik;

import com.google.gson.Gson;

import jakarta.inject.Inject;
import jakarta.servlet.ServletContext;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

/**
 * Klasa RestKorisnici.
 */
@Path("korisnici")
public class RestKorisnici {

	/** The pbp. */
	PostavkeBazaPodataka pbp;
	
	/** The context. */
	@Inject
	ServletContext context;

	/**
	 * Instancira klasu RestKorisnici.
	 *
	 * @param context the context
	 */
	@Inject
	public RestKorisnici(ServletContext context) {
		this.context = context;
		this.pbp = (PostavkeBazaPodataka) context.getAttribute("postavke");
	}

	/**
	 * Daj sve korisnike.
	 *
	 * @param korisnik the korisnik
	 * @param zeton the zeton
	 * @return the response
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	public Response dajSveKorisnike(@HeaderParam("korisnik") String korisnik, @HeaderParam("zeton") int zeton) {
		Response odgovor = null;
		ArrayList<Korisnik> korisnici = new ArrayList<>();
		
		KorisniciDAO korisniciDAO = new KorisniciDAO();
		
		Zeton z = korisniciDAO.provjeraZetona(zeton, korisnik, pbp);
		
		if(z == null) {
			odgovor = Response.status(Response.Status.NOT_FOUND)
					.entity("Token ne postoji!").build();
		}
		else if(z.korisnik.equals(korisnik) && z.status==1) {
			korisnici = korisniciDAO.dajSveKorisnike(pbp);
			if (korisnici != null) {
				odgovor = Response.status(Response.Status.OK).entity(korisnici).build();
			} else {
				odgovor = Response.status(Response.Status.NOT_FOUND).entity("Nema korisnika.").build();
			}
		}
		else if(!z.korisnik.equals(korisnik)) {
			odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("Zeton ne pripada korisniku").build();
		}
		else if(z.status == 0 || z.vrijeme < LocalDateTime.now().toLocalTime().toSecondOfDay()) {
			odgovor = Response.status(Response.Status.REQUEST_TIMEOUT).entity("Zeton nije aktivan ili je istekao").build();
		}

		return odgovor;
	}
	
	/**
	 * Dodaj korisnika.
	 *
	 * @param korisnik the korisnik
	 * @param zeton the zeton
	 * @param korisnik1 the korisnik 1
	 * @return the response
	 */
	@POST
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	public Response dodajKorisnika(@HeaderParam("korisnik") String korisnik, @HeaderParam("zeton") int zeton, String korisnik1) {
		Response odgovor = null;
		Korisnik noviKorisnik = new Korisnik();
		Gson gson = new Gson();
		
		noviKorisnik = gson.fromJson(korisnik1, Korisnik.class);
		
		KorisniciDAO korisniciDAO = new KorisniciDAO();
		Zeton z = korisniciDAO.provjeraZetona(zeton, korisnik, pbp);

		if(z == null) {
			odgovor = Response.status(Response.Status.NOT_FOUND)
					.entity("Token ne postoji!").build();
		}
		else if(z.korisnik.equals(korisnik) && z.status==1) {
			boolean dodaj = korisniciDAO.dodajKorisnika(noviKorisnik, pbp);
			
			if(dodaj) odgovor = Response.status(Response.Status.OK).entity("Korisnik dodan").build();
			else odgovor = Response.status(Response.Status.NOT_FOUND).entity("Korisnik nije dodan").build();
		}
		else if(!z.korisnik.equals(korisnik)) {
			odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("Zeton ne pripada korisniku").build();
		}
		else if(z.status == 0 || z.vrijeme < LocalDateTime.now().toLocalTime().toSecondOfDay()) {
			odgovor = Response.status(Response.Status.REQUEST_TIMEOUT).entity("Zeton nije aktivan ili je istekao").build();
		}

		return odgovor;
	}
	
	/**
	 * Daj izabranog korisnika.
	 *
	 * @param korisnikIzabrani the korisnik izabrani
	 * @param korisnik the korisnik
	 * @param zeton the zeton
	 * @return the response
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("{korisnik}")
	public Response dajIzabranogKorisnika(@PathParam("korisnik") String korisnikIzabrani, @HeaderParam("korisnik") String korisnik, @HeaderParam("zeton") int zeton) {
		Response odgovor = null;
		ArrayList<Korisnik> korisnici = new ArrayList<>();
		
		System.out.println("Dobije: " + korisnik + " " + zeton + " "+ korisnikIzabrani);
		
		KorisniciDAO korisniciDAO = new KorisniciDAO();
		korisnici = korisniciDAO.dajSveKorisnike(pbp);
		Zeton z = korisniciDAO.provjeraZetona(zeton, korisnik, pbp);
		
		if(z == null) {
			odgovor = Response.status(Response.Status.NOT_FOUND)
					.entity("Token ne postoji!").build();
		}
		else if(z.korisnik.equals(korisnik) && z.status==1) {
			for (Korisnik k : korisnici) {
				if (k.getKorIme().compareTo(korisnikIzabrani) == 0) {
					odgovor = Response.status(Response.Status.OK).entity(k).build();
					break;
				}
			}
		}
		else if(!z.korisnik.equals(korisnik)) {
			odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("Zeton ne pripada korisniku").build();
		}
		else if(z.status == 0 || z.vrijeme < LocalDateTime.now().toLocalTime().toSecondOfDay()) {
			odgovor = Response.status(Response.Status.REQUEST_TIMEOUT).entity("Zeton nije aktivan ili je istekao").build();
		}
		
		return odgovor;
	}
	
	/**
	 * Daj grupe korisnika.
	 *
	 * @param korisnik the korisnik
	 * @param zeton the zeton
	 * @param korisnikIzabrani the korisnik izabrani
	 * @return the response
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("{korisnici}/grupe")
	public Response dajGrupeKorisnika(@HeaderParam("korisnik") String korisnik, @HeaderParam("zeton") int zeton, @PathParam("korisnici") String korisnikIzabrani) {
		Response odgovor = null;
		ArrayList<Grupa> grupe = new ArrayList<>();
		
		KorisniciDAO korisniciDAO = new KorisniciDAO();
		Zeton z = korisniciDAO.provjeraZetona(zeton, korisnik, pbp);
		
		if(z == null) {
			odgovor = Response.status(Response.Status.NOT_FOUND)
					.entity("Token ne postoji!").build();
		}
		else if(z.korisnik.equals(korisnik) && z.status==1) {
			grupe = korisniciDAO.dajGrupeKorisnika(korisnikIzabrani, pbp);
			odgovor = Response.status(Response.Status.OK).entity(grupe).build();
		}
		else if(!z.korisnik.equals(korisnik)) {
			odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("Zeton ne pripada korisniku").build();
		}
		else if(z.status == 0 || z.vrijeme < LocalDateTime.now().toLocalTime().toSecondOfDay()) {
			odgovor = Response.status(Response.Status.REQUEST_TIMEOUT).entity("Zeton nije aktivan ili je istekao").build();
		}
		
		return odgovor;
	}
	
}
