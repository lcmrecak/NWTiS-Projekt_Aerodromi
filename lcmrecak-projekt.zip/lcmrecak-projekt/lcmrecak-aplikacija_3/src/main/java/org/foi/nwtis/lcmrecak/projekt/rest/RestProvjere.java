package org.foi.nwtis.lcmrecak.projekt.rest;

import java.time.LocalDateTime;

import org.foi.nwtis.lcmrecak.projekt.podaci.ProvjereDAO;
import org.foi.nwtis.lcmrecak.projekt.podaci.Zeton;
import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;

import jakarta.inject.Inject;
import jakarta.servlet.ServletContext;
import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

/**
 * Klasa RestProvjere.
 */
@Path("provjere")
public class RestProvjere {

	/** The pbp. */
	PostavkeBazaPodataka pbp;
	
	/** The context. */
	@Inject
	ServletContext context;

	/**
	 * Instancira klasu RestProvjere.
	 *
	 * @param context the context
	 */
	@Inject
	public RestProvjere(ServletContext context) {
		this.context = context;
		this.pbp = (PostavkeBazaPodataka) context.getAttribute("postavke");
		System.out.println("REST se otprl");
	}

	/**
	 * Provjera autentikacija.
	 *
	 * @param korisnik the korisnik
	 * @param lozinka the lozinka
	 * @return the response
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	public Response provjeraAutentikacija(@HeaderParam("korisnik") String korisnik,
			@HeaderParam("lozinka") String lozinka) {
		Response odgovor = null;
		String autentikacija = "";

		if (!(korisnik==null)) {
			ProvjereDAO provjereDAO = new ProvjereDAO();
			autentikacija = provjereDAO.provjeraAutentikacija(korisnik, lozinka, pbp);

			if (autentikacija != "401") {
				odgovor = Response.status(Response.Status.OK).entity(autentikacija).build();
			}
			else {
				odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("Autentikacija nije uspjela").build();
			}
		}
		return odgovor;
	}

	/**
	 * Provjera zetona.
	 *
	 * @param korisnik the korisnik
	 * @param lozinka the lozinka
	 * @param token the token
	 * @return the response
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("{token}")
	public Response provjeraZetona(@HeaderParam("korisnik") String korisnik, @HeaderParam("lozinka") String lozinka,
			@PathParam("token") int token) {
		Response odgovor = null;
		
		System.out.println("Zeton je: " + token);

		ProvjereDAO provjereDAO = new ProvjereDAO();
		Zeton zeton1 = provjereDAO.provjeraZetona(token, pbp);
		
		
		if(zeton1 == null) {
			odgovor = Response.status(Response.Status.NOT_FOUND)
					.entity("Token ne postoji!").build();
		}
		else if (!zeton1.korisnik.equals(korisnik)) {
			odgovor = Response.status(Response.Status.UNAUTHORIZED)
					.entity("Korisnik se ne podudara ili token nije važeći").build();
		} else if (zeton1.vrijeme < LocalDateTime.now().toLocalTime().toSecondOfDay()) {
			odgovor = Response.status(Response.Status.REQUEST_TIMEOUT).entity("Zeton je istekao/neaktivan").build();
		} else if (zeton1.status == 1 && zeton1.korisnik.equals(korisnik)
				&& zeton1.vrijeme >= LocalDateTime.now().toLocalTime().toSecondOfDay()) {
			odgovor = Response.status(Response.Status.OK).entity("Zeton je aktivan").build();
		}

		return odgovor;
	}

	/**
	 * Update zetona.
	 *
	 * @param korisnik the korisnik
	 * @param lozinka the lozinka
	 * @param zeton the zeton
	 * @return the response
	 */
	@DELETE
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("{token}")
	public Response updateZetona(@HeaderParam("korisnik") String korisnik, @HeaderParam("lozinka") String lozinka,
			@PathParam("token") int zeton) {
		Response odgovor = null;

		System.out.println("Zeton: " + zeton);
		
		ProvjereDAO provjereDAO = new ProvjereDAO();
		Zeton zeton1 = provjereDAO.provjeraZetona(zeton, pbp);

		if(zeton1 == null) {
			odgovor = Response.status(Response.Status.NOT_FOUND)
					.entity("Token ne postoji!").build();
		}
		else if (zeton1.status == 1 && zeton1.korisnik.equals(korisnik)
				&& zeton1.vrijeme >= LocalDateTime.now().toLocalTime().toSecondOfDay()) {
			provjereDAO.updateZetona(zeton, pbp);
			odgovor = Response.status(Response.Status.OK).entity("Zeton je azuriran").build();
		} else if (zeton1.status == 0 || !zeton1.korisnik.equals(korisnik)) {
			odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("Korisnik se ne podudara").build();
		} else if (zeton1.status == 0 || zeton1.vrijeme >= LocalDateTime.now().toLocalTime().toSecondOfDay()) {
			odgovor = Response.status(Response.Status.REQUEST_TIMEOUT).entity("Isteklo vrijeme zetona").build();
		}

		return odgovor;
	}

	/**
	 * Brisanje zetona.
	 *
	 * @param korisnik the korisnik
	 * @param lozinka the lozinka
	 * @param korisnik1 the korisnik 1
	 * @return the response
	 */
	@DELETE
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("korisnik/{korisnik}")
	public Response brisanjeZetona(@HeaderParam("korisnik") String korisnik, @HeaderParam("lozinka") String lozinka,
			@PathParam("korisnik") String korisnik1) {
		Response odgovor = null;
		String grupa = pbp.dajPostavku("sustav.administratori");

		ProvjereDAO provjereDAO = new ProvjereDAO();
		boolean korisnikAdmin = provjereDAO.adminProvjera(korisnik, pbp);
		
		System.out.println("Je admin:"  +korisnikAdmin + " Primljeni korisnik i lozinka: " + korisnik + lozinka);

		if (korisnikAdmin) {
			boolean azurirano = provjereDAO.brisanjeZetona(korisnik1, pbp);
			if (azurirano)
				odgovor = Response.status(Response.Status.OK).entity("Zetoni su azurirani").build();
			else
				odgovor = Response.status(Response.Status.NOT_FOUND).entity("Korisnik nema niti jedan aktivan zeton")
						.build();
		}
		if (korisnikAdmin == false) {
			if (korisnik.equals(korisnik1)) {
				boolean azurirano = provjereDAO.brisanjeZetona(korisnik1, pbp);
				if (azurirano)
					odgovor = Response.status(Response.Status.OK).entity("Zetoni su azurirani").build();
			} else
				odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("Korisnik nema ovlastenje za brisanje")
						.build();
		}

		return odgovor;
	}

}
