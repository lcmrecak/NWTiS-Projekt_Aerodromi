package org.foi.nwtis.lcmrecak.projekt.rest;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.time.LocalDateTime;
import java.util.List;

import org.foi.nwtis.lcmrecak.projekt.podaci.AerodromPraceniDAO;
import org.foi.nwtis.lcmrecak.projekt.podaci.KorisniciDAO;
import org.foi.nwtis.lcmrecak.projekt.podaci.Zeton;
import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.podaci.Aerodrom;

import com.google.gson.Gson;

import jakarta.inject.Inject;
import jakarta.servlet.ServletContext;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

/**
 * Klasa RestServeri.
 */
@Path("serveri")
public class RestServeri {

	/** The pbp. */
	PostavkeBazaPodataka pbp;
	
	/** The context. */
	@Inject
	ServletContext context;
	
	/**
	 * Instancira klasu RestServeri.
	 *
	 * @param context the context
	 */
	@Inject
	public RestServeri(ServletContext context){
		this.context = context;
		this.pbp = (PostavkeBazaPodataka) context.getAttribute("postavke");
	}
	
	/**
	 * Daj status.
	 *
	 * @param korisnik the korisnik
	 * @param zeton the zeton
	 * @return the response
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	public Response dajStatus(@HeaderParam("korisnik") String korisnik, @HeaderParam("zeton") int zeton) {
		Response odgovor = null;
		String greska = "";
		String povratniOdgovor = "";
		
		KorisniciDAO korisniciDAO = new KorisniciDAO();
		Zeton z = korisniciDAO.provjeraZetona(zeton, korisnik, pbp);
		
		String komanda = "STATUS";

		if(z == null) {
			odgovor = Response.status(Response.Status.NOT_FOUND)
					.entity("Token ne postoji!").build();
		}
		else if(z.korisnik.equals(korisnik) && z.status==1) {
			try (Socket veza = new Socket(pbp.dajPostavku("adresa.servera"), Integer.parseInt(pbp.dajPostavku("port")));
					InputStream is = veza.getInputStream();
					OutputStream os = veza.getOutputStream();
					OutputStreamWriter osw = new OutputStreamWriter(os)) {
				
				osw.write(komanda);
	            osw.flush();
	            veza.shutdownOutput();
	            
	            StringBuilder tekst = new StringBuilder();
	            while(true) {
	            	int i = is.read();
	            	if(i == -1) {
	            		break;
	            	}
	            	tekst.append((char) i);
	            }
	            veza.shutdownInput();
	            veza.close();
	           
	            povratniOdgovor = tekst.toString();
	            
	            System.out.println(povratniOdgovor);
				
			} catch (NumberFormatException | IOException e) {
				
				odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("GRESKA Server ne radi").build();
			}
			if(povratniOdgovor.equals("OK 0") || povratniOdgovor.equals("OK 1") || povratniOdgovor.equals("OK 2")) {
				odgovor = Response.status(Response.Status.OK).entity(povratniOdgovor).build();
			}
		}
		else if(!z.korisnik.equals(korisnik)) {
			odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("Zeton ne pripada korisniku").build();
		}
		else if(z.status == 0 || z.vrijeme < LocalDateTime.now().toLocalTime().toSecondOfDay()) {
			odgovor = Response.status(Response.Status.REQUEST_TIMEOUT).entity("Zeton nije aktivan ili je istekao").build();
		}
		return odgovor;
	}
	
	/**
	 * Posalji komandu.
	 *
	 * @param korisnik the korisnik
	 * @param zeton the zeton
	 * @param komanda the komanda
	 * @return the response
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("{komanda}")
	public Response posaljiKomandu(@HeaderParam("korisnik") String korisnik, @HeaderParam("zeton") int zeton, @PathParam("komanda") String komanda) {
		Response odgovor = null;
		String greska = "";
		String povratniOdgovor = "";
		
		KorisniciDAO korisniciDAO = new KorisniciDAO();
		Zeton z = korisniciDAO.provjeraZetona(zeton, korisnik, pbp);

		if(z == null) {
			odgovor = Response.status(Response.Status.NOT_FOUND)
					.entity("Token ne postoji!").build();
		}
		else if(z.korisnik.equals(korisnik) && z.status==1) {
			try (Socket veza = new Socket(pbp.dajPostavku("adresa.servera"), Integer.parseInt(pbp.dajPostavku("port")));
					InputStream is = veza.getInputStream();
					OutputStream os = veza.getOutputStream();
					OutputStreamWriter osw = new OutputStreamWriter(os)) {
				
				osw.write(komanda);
	            osw.flush();
	            veza.shutdownOutput();
	            
	            StringBuilder tekst = new StringBuilder();
	            while(true) {
	            	int i = is.read();
	            	if(i == -1) {
	            		break;
	            	}
	            	tekst.append((char) i);
	            }
	            veza.shutdownInput();
	            veza.close();
	            
	            String[] status = tekst.toString().split(" ");
	            greska = tekst.toString();
	            povratniOdgovor = status[0];
				
			} catch (NumberFormatException | IOException e) {
				
				odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("GRESKA Server ne radi").build();
			}
			if(povratniOdgovor.equals("OK")) {
				odgovor = Response.status(Response.Status.OK).entity(povratniOdgovor).build();
			}
			else odgovor = Response.status(Response.Status.BAD_REQUEST).entity(greska).build();
		}
		else if(!z.korisnik.equals(korisnik)) {
			odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("Zeton ne pripada korisniku").build();
		}
		else if(z.status == 0 || z.vrijeme < LocalDateTime.now().toLocalTime().toSecondOfDay()) {
			odgovor = Response.status(Response.Status.REQUEST_TIMEOUT).entity("Zeton nije aktivan ili je istekao").build();
		}
		return odgovor;
	}
	
	/**
	 * Posalji kolekciju aerodroma.
	 *
	 * @param korisnik the korisnik
	 * @param zeton the zeton
	 * @return the response
	 */
	@POST
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/LOAD")
	public Response posaljiKolekcijuAerodroma(@HeaderParam("korisnik") String korisnik, @HeaderParam("zeton") int zeton) {
		Response odgovor = null;
		String greska = "";
		String povratniOdgovor = "";
		
		KorisniciDAO korisniciDAO = new KorisniciDAO();
		AerodromPraceniDAO aerodromiDAO = new AerodromPraceniDAO();
		Zeton z = korisniciDAO.provjeraZetona(zeton, korisnik, pbp);
		
		List<Aerodrom> aerodromi = aerodromiDAO.dajAerodromeZaPratiti(pbp);
		
		String aerodromiJson = new Gson().toJson(aerodromi);

		if(z == null) {
			odgovor = Response.status(Response.Status.NOT_FOUND)
					.entity("Token ne postoji!").build();
		}
		else if(z.korisnik.equals(korisnik) && z.status==1) {
			try (Socket veza = new Socket(pbp.dajPostavku("adresa.servera"), Integer.parseInt(pbp.dajPostavku("port")));
					InputStream is = veza.getInputStream();
					OutputStream os = veza.getOutputStream();
					OutputStreamWriter osw = new OutputStreamWriter(os)) {
				
				String komanda = "LOAD " + aerodromiJson;
				osw.write(komanda);
	            osw.flush();
	            veza.shutdownOutput();
	            
	            StringBuilder tekst = new StringBuilder();
	            while(true) {
	            	int i = is.read();
	            	if(i == -1) {
	            		break;
	            	}
	            	tekst.append((char) i);
	            }
	            veza.shutdownInput();
	            veza.close();
	            
	            String[] status = tekst.toString().split(" ");
	            greska = tekst.toString();
	            povratniOdgovor = status[0];
				
			} catch (NumberFormatException | IOException e) {
				
				odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("GRESKA Server ne radi").build();
			}
			if(povratniOdgovor=="OK") {
				odgovor = Response.status(Response.Status.OK).entity(povratniOdgovor).build();
			}
			else odgovor = Response.status(Response.Status.CONFLICT).entity(greska).build();
		}
		else if(!z.korisnik.equals(korisnik)) {
			odgovor = Response.status(Response.Status.UNAUTHORIZED).entity("Zeton ne pripada korisniku").build();
		}
		else if(z.status == 0 || z.vrijeme < LocalDateTime.now().toLocalTime().toSecondOfDay()) {
			odgovor = Response.status(Response.Status.REQUEST_TIMEOUT).entity("Zeton nije aktivan ili je istekao").build();
		}
		return odgovor;
	}
}
