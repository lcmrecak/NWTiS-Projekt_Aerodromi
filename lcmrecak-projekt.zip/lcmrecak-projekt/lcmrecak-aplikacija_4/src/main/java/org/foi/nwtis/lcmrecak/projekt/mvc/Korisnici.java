package org.foi.nwtis.lcmrecak.projekt.mvc;

import java.util.List;

import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.podaci.Korisnik;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.View;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;

/**
 * Klasa Korisnici.
 */
@Controller
@Path("korisnici")
@RequestScoped
public class Korisnici {

	/** The pbp. */
	PostavkeBazaPodataka pbp;
	
	/** The context. */
	@Inject
	ServletContext context;

	/**
	 * Instancira klasu Korisnici.
	 *
	 * @param context the context
	 */
	@Inject
	public Korisnici(ServletContext context) {
		this.context = context;
		this.pbp = (PostavkeBazaPodataka) context.getAttribute("postavke");
	}

	/**
	 * Prazni konstruktor.
	 */
	public Korisnici() {

	}

	/** The model. */
	@Inject
	private Models model;

	/**
	 * Pocetak.
	 */
	@GET
	@Path("pocetak")
	@View("index.jsp")
	public void pocetak() {
	}

	/**
	 * Registracija korisnika.
	 */
	@GET
	@Path("registracija")
	@View("registracija.jsp")
	public void registracijaKorisnika() {

	}

	/**
	 * Registracija korisnika.
	 *
	 * @param korime the korime
	 * @param ime the ime
	 * @param prezime the prezime
	 * @param lozinka the lozinka
	 * @param email the email
	 */
	@POST
	@Path("registracija")
	@View("registracija.jsp")
	@Consumes({ MediaType.APPLICATION_FORM_URLENCODED })
	public void registracijaKorisnika(@FormParam("korime") String korime, @FormParam("ime") String ime,
			@FormParam("prezime") String prezime, @FormParam("lozinka") String lozinka,
			@FormParam("email") String email) {

		KorisniciKlijent registacijaKorisnika = new KorisniciKlijent(context);
		Korisnik korisnik = new Korisnik(korime, ime, prezime, lozinka, email);

		registacijaKorisnika.registracijaKorisnika(korisnik);

	}

	/**
	 * Pregled prijava korisnika.
	 *
	 * @param korime the korime
	 * @param lozinka the lozinka
	 * @param request the request
	 */
	@GET
	@Path("prijava")
	@View("prijava.jsp")
	public void prijavaKorisnika(@QueryParam("korime") String korime, @QueryParam("lozinka") String lozinka, @Context HttpServletRequest request) {

		KorisniciKlijent prijavaKorisnika = new KorisniciKlijent(context);
		
		if(!(korime==null)) {
			System.out.println(korime + " " + lozinka + " "+ request);
			prijavaKorisnika.prijavaKorisnika(korime, lozinka, request);
		}
	}
	
	/**
	 * Pregled korisnika.
	 *
	 * @param request the request
	 */
	@GET
	@Path("pregledKorisnika")
	@View("pregledKorisnika.jsp")
	public void pregledKorisnika(@Context HttpServletRequest request) {

		KorisniciKlijent pregledKorisnika = new KorisniciKlijent(context);
		
		List<Korisnik> korisnici = pregledKorisnika.dajSveKorisnike(request);
		model.put("korisnici", korisnici);
	}
	
	/**
	 * Pregled korisnika brisanje.
	 *
	 * @param korisnik the korisnik
	 * @param request the request
	 */
	@GET
	@Path("pregledKorisnikaBrisanje")
	@View("pregledKorisnika.jsp")
	public void pregledKorisnikaBrisanje(@QueryParam("korisnik") String korisnik, @Context HttpServletRequest request) {

		KorisniciKlijent pregledKorisnika = new KorisniciKlijent(context);
		
		String odgovor = pregledKorisnika.obrisiZetoneKorisnika (korisnik, request);
		
		List<Korisnik> korisnici = pregledKorisnika.dajSveKorisnike(request);
		model.put("poruka", odgovor);
		model.put("korisnici", korisnici);
	}
	
	/**
	 * Pregled korisnika brisanje zadnjeg.
	 *
	 * @param korisnik the korisnik
	 * @param request the request
	 */
	@GET
	@Path("pregledKorisnikaBrisanjeZadnjeg")
	@View("pregledKorisnika.jsp")
	public void pregledKorisnikaBrisanjeZadnjeg(@QueryParam("korisnik") String korisnik, @Context HttpServletRequest request) {

		KorisniciKlijent pregledKorisnika = new KorisniciKlijent(context);
		
		String odgovor = pregledKorisnika.obrisiZadnjiZeton(request);
		
		List<Korisnik> korisnici = pregledKorisnika.dajSveKorisnike(request);
		model.put("poruka", odgovor);
		model.put("korisnici", korisnici);
	}
	
	/**
	 * Pregled upravljanje posluziteljem.
	 *
	 * @param komanda the komanda
	 * @param request the request
	 */
	@GET
	@Path("upravljanjePosluziteljem")
	@View("upravljanjePosluziteljem.jsp")
	public void upravljanjePosluziteljem(@QueryParam("komanda") String komanda, @Context HttpServletRequest request) {
		KorisniciKlijent slanjeKomande = new KorisniciKlijent(context);

		String status = slanjeKomande.posaljiKomandu(komanda, request);
		
		model.put("status", status);

	}
	
}
