package org.foi.nwtis.lcmrecak.projekt.mvc;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.podaci.Korisnik;

import com.google.gson.Gson;

import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response;

/**
 * Klasa AerodromiKlijent.
 */
public class KorisniciKlijent {

	HttpSession session = null;

	private PostavkeBazaPodataka pbp;

	public KorisniciKlijent(ServletContext context) {

		this.pbp = (PostavkeBazaPodataka) context.getAttribute("postavke");
	}

	public boolean registracijaKorisnika(Korisnik korisnik) {
		Client client = ClientBuilder.newClient();
		String zeton = "";

		WebTarget webResource = client.target(pbp.dajPostavku("aplikacija3.adresa")).path("korisnici");

		WebTarget webResourceProvjere = client.target(pbp.dajPostavku("aplikacija3.adresa")).path("provjere");

		Response restOdgovorProvjera = webResourceProvjere.request().header("Accept", "application/json")
				.header("korisnik", pbp.dajPostavku("sustav.korisnik"))
				.header("lozinka", pbp.dajPostavku("sustav.lozinka")).get();

		if (restOdgovorProvjera.getStatus() == 200) {
			zeton = restOdgovorProvjera.readEntity(String.class).split(" ")[1];
			zeton = zeton.substring(0, zeton.length() - 1);
		}

		Response restOdgovor = webResource.request().header("Accept", "application/json")
				.header("korisnik", pbp.dajPostavku("sustav.korisnik")).header("zeton", zeton)
				.post(Entity.json(korisnik));

		if (restOdgovor.getStatus() == 200)
			return true;

		return false;
	}

	public boolean prijavaKorisnika(String korime, String lozinka, HttpServletRequest request) {
		Client client = ClientBuilder.newClient();
		String zeton = "";
		System.out.println("U SESIJE: " + korime + " " + lozinka);
		WebTarget webResourceProvjere = client.target(pbp.dajPostavku("aplikacija3.adresa")).path("provjere");

		Response restPrijava = webResourceProvjere.request().header("Accept", "application/json")
				.header("korisnik", korime).header("lozinka", lozinka).get();

		if (restPrijava.getStatus() == 200) {
			zeton = restPrijava.readEntity(String.class).split(" ")[1];
			zeton = zeton.substring(0, zeton.length() - 1);

			session = request.getSession();
			session.setAttribute("korime", korime);
			session.setAttribute("zeton", zeton);
			session.setAttribute("lozinka", lozinka);

			return true;
		}

		return false;

	}

	public List<Korisnik> dajSveKorisnike(HttpServletRequest request) {
		session = request.getSession();
		String korisnik = session.getAttribute("korime").toString();
		String zeton = session.getAttribute("zeton").toString();

		Client client = ClientBuilder.newClient();
		WebTarget webResource = client.target(pbp.dajPostavku("aplikacija3.adresa")).path("korisnici");

		Response restOdgovor = webResource.request().header("Accept", "application/json").header("korisnik", korisnik)
				.header("zeton", zeton).get();

		List<Korisnik> korisnici = null;
		if (restOdgovor.getStatus() == 200) {
			String odgovor = restOdgovor.readEntity(String.class);
			Gson gson = new Gson();
			korisnici = new ArrayList<>();
			korisnici.addAll(Arrays.asList(gson.fromJson(odgovor, Korisnik[].class)));
		}
		return korisnici;
	}

	public String obrisiZetoneKorisnika(String korisnik, HttpServletRequest request) {
		session = request.getSession();
		String korime = session.getAttribute("korime").toString();
		String lozinka = session.getAttribute("lozinka").toString();

		String odgovor = "";
		Client client = ClientBuilder.newClient();

		System.out.println("Poslani korisnik: " + korisnik);

		WebTarget webResourceProvjere = client.target(pbp.dajPostavku("aplikacija3.adresa")).path("provjere")
				.path("korisnik").path(korisnik);

		Response restBrisanje = webResourceProvjere.request().header("Accept", "application/json")
				.header("korisnik", korime).header("lozinka", lozinka).delete();

		if (restBrisanje.getStatus() == 200) {
			odgovor = "Žetoni su uspješno obrisani!";
		} else
			odgovor = "Korisnik nema pravo na brisanje tuđih žetona";

		return odgovor;

	}

	public String obrisiZadnjiZeton(HttpServletRequest request) {
		session = request.getSession();
		String korime = session.getAttribute("korime").toString();
		String lozinka = session.getAttribute("lozinka").toString();
		String zeton = session.getAttribute("zeton").toString();

		String odgovor = "";
		Client client = ClientBuilder.newClient();

		System.out.println("Poslani korisnik: " + korime + " " + zeton);

		WebTarget webResourceProvjere = client.target(pbp.dajPostavku("aplikacija3.adresa")).path("provjere")
				.path(zeton);

		Response restBrisanje = webResourceProvjere.request().header("Accept", "application/json")
				.header("korisnik", korime).header("lozinka", lozinka).delete();

		if (restBrisanje.getStatus() == 200) {
			odgovor = "Žeton je uspješno obrisan!";
		} else
			odgovor = "Žeton nije obrisan";

		return odgovor;
	}

	public String dohvatiStatus() {
		String povratniOdgovor = "";

		try (Socket veza = new Socket(pbp.dajPostavku("adresa.servera"), Integer.parseInt(pbp.dajPostavku("port")));
				InputStream is = veza.getInputStream();
				OutputStream os = veza.getOutputStream();
				OutputStreamWriter osw = new OutputStreamWriter(os)) {

			osw.write("STATUS");
			osw.flush();
			veza.shutdownOutput();

			StringBuilder tekst = new StringBuilder();
			while (true) {
				int i = is.read();
				if (i == -1) {
					break;
				}
				tekst.append((char) i);
			}
			veza.shutdownInput();
			veza.close();

			povratniOdgovor = tekst.toString();

			System.out.println(povratniOdgovor);

		} catch (NumberFormatException | IOException e) {

			povratniOdgovor = "Greska: Server ne radi";
		}

		return povratniOdgovor;

	}

	public String posaljiKomandu(String komanda, HttpServletRequest request) {
		if (komanda == null) {
			String status = dohvatiStatus();
			return status;
		} else {

			if (komanda.equals("LOAD")) {

				String aerodromi = dohvatiPraceneAerodrome(request);
				komanda = "LOAD " + aerodromi;
			}

			String povratniOdgovor = "";

			try (Socket veza = new Socket(pbp.dajPostavku("adresa.servera"), Integer.parseInt(pbp.dajPostavku("port")));
					InputStream is = veza.getInputStream();
					OutputStream os = veza.getOutputStream();
					OutputStreamWriter osw = new OutputStreamWriter(os)) {

				osw.write(komanda);
				osw.flush();
				veza.shutdownOutput();

				StringBuilder tekst = new StringBuilder();
				while (true) {
					int i = is.read();
					if (i == -1) {
						break;
					}
					tekst.append((char) i);
				}
				veza.shutdownInput();
				veza.close();

				povratniOdgovor = tekst.toString();

				System.out.println(povratniOdgovor);

			} catch (NumberFormatException | IOException e) {

				povratniOdgovor = "Greska: Server ne radi";
			}
			String status = dohvatiStatus();
			povratniOdgovor = status + " " + povratniOdgovor;
			return povratniOdgovor;
		}

	}

	public String dohvatiPraceneAerodrome(HttpServletRequest request) {
		session = request.getSession();
		String korime = session.getAttribute("korime").toString();
		String lozinka = session.getAttribute("lozinka").toString();
		String zeton = session.getAttribute("zeton").toString();

		String odgovor = "";
		Client client = ClientBuilder.newClient();

		System.out.println("Poslani korisnik: " + korime + " " + zeton);

		WebTarget webResource = client.target(pbp.dajPostavku("aplikacija3.adresa")).path("aerodromi");

		Response restOdgovor = webResource.request().header("Accept", "application/json").header("korisnik", korime)
				.header("zeton", zeton).get();

		odgovor = restOdgovor.readEntity(String.class);

		return odgovor;
	}

}
