package org.foi.nwtis.lcmrecak.projekt.mvc;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("mvc")
public class MVC extends Application {

}
