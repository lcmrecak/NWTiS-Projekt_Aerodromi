package org.foi.nwtis.lcmrecak.projekt.slusaci;

import java.io.File;

import org.foi.nwtis.lcmrecak.vjezba_03.konfiguracije.NeispravnaKonfiguracija;
import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

/**
 * Implementacija slusaca zivotnog ciklusa aplikacije - klasa SlusacAplikacije.
 */
@WebListener
public class SlusacAplikacije implements ServletContextListener {

	
    /**
     * Prazni konstruktor. 
     */
    public SlusacAplikacije() {
    }

	/**
	 * Inicijalizacija contexta.
	 *
	 * @param sce the sce
	 */
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		ServletContext context = sce.getServletContext();
		String nazivDatoteke = context.getInitParameter("konfiguracija");
		PostavkeBazaPodataka konfig = null;
		String putanja = context.getRealPath("WEB-INF") + File.separator + nazivDatoteke;
		try {
			konfig = new PostavkeBazaPodataka(putanja);
			konfig.ucitajKonfiguraciju();
			context.setAttribute("Postavke", konfig);
			System.out.println("Učitana konfiguracijska datoteka.");
		} catch (NeispravnaKonfiguracija e1) {
			e1.printStackTrace();
			return;
		}

		ServletContextListener.super.contextInitialized(sce);
	}
	
	/**
	 * Context uništen.
	 *
	 * @param sce the sce
	 */
	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		ServletContext context = sce.getServletContext();
		context.removeAttribute("Postavke");

		ServletContextListener.super.contextDestroyed(sce);
	}

}
