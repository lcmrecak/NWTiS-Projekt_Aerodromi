package org.foi.nwtis.lcmrecak.projekt.ws;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.podaci.Korisnik;
import org.foi.nwtis.rest.podaci.AvionLeti;

import com.google.gson.Gson;

import jakarta.annotation.Resource;
import jakarta.inject.Inject;
import jakarta.jws.WebMethod;
import jakarta.jws.WebService;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpSession;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response;
import jakarta.xml.ws.WebServiceContext;
import jakarta.xml.ws.handler.MessageContext;

/**
 * Klasa WsAerodromi.
 */
@WebService(serviceName = "aerodromi")
public class WsAerodromi {
	
	/** The ws context. */
	@Resource
	private WebServiceContext wsContext;

	/**
	 * Daj polaske dan.
	 *
	 * @param korisnik the korisnik
	 * @param zeton the zeton
	 * @param icao the icao
	 * @param danOd the dan od
	 * @param danDo the dan do
	 * @return the list
	 */
	@WebMethod
	public List<AvionLeti> dajPolaskeDan(String korisnik, String zeton, String icao, String danOd, String danDo) {
		List<AvionLeti> aerodromi = new ArrayList<>();
		
		System.out.println("Prima od soapa: "+ icao + " "+ danOd + " " +danDo);
		
		Client client = ClientBuilder.newClient();
		
		WebTarget webResource = client.target(dajPBP().dajPostavku("aplikacija3.adresa")).path("aerodromi").path(icao).path("polasci").queryParam("vrsta", "0").queryParam("od", danOd).queryParam("do", danDo);

		Response restOdgovor = webResource.request().header("Accept", "application/json")
				.header("korisnik", korisnik)
				.header("zeton", zeton).
				get();

		if (restOdgovor.getStatus() == 200) {
			String odgovor = restOdgovor.readEntity(String.class);
			Gson gson = new Gson();
			aerodromi = new ArrayList<>();
			aerodromi.addAll(Arrays.asList(gson.fromJson(odgovor, AvionLeti[].class)));
		}
		
		return aerodromi;
	}
	
	/**
	 * Daj polaske vrijeme.
	 *
	 * @param korisnik the korisnik
	 * @param zeton the zeton
	 * @param icao the icao
	 * @param danOd the dan od
	 * @param danDo the dan do
	 * @return the list
	 */
	@WebMethod
	public List<AvionLeti> dajPolaskeVrijeme(String korisnik, String zeton, String icao, String danOd, String danDo) {
		List<AvionLeti> aerodromi = new ArrayList<>();

		Client client = ClientBuilder.newClient();
		
		WebTarget webResource = client.target(dajPBP().dajPostavku("aplikacija3.adresa")).path("aerodromi").path(icao).path("polasci").queryParam("vrsta", "1").queryParam("od", danOd).queryParam("do", danDo);;

		Response restOdgovor = webResource.request().header("Accept", "application/json")
				.header("korisnik", korisnik)
				.header("zeton", zeton).
				get();

		if (restOdgovor.getStatus() == 200) {
			String odgovor = restOdgovor.readEntity(String.class);
			Gson gson = new Gson();
			aerodromi = new ArrayList<>();
			aerodromi.addAll(Arrays.asList(gson.fromJson(odgovor, AvionLeti[].class)));
		}
		
		return aerodromi;
	}
	
	/**
	 * Dodaj aerodrom preuzimanje.
	 *
	 * @param korisnik the korisnik
	 * @param zeton the zeton
	 * @param icao the icao
	 * @return true, if successful
	 */
	@WebMethod
	public boolean dodajAerodromPreuzimanje(String korisnik, String zeton, String icao) {
		Client client = ClientBuilder.newClient();
		
		WebTarget webResourceDodaj = client.target(dajPBP().dajPostavku("aplikacija3.adresa")).path("aerodromi");

		Response restOdgovorDodaj = webResourceDodaj.request().header("Accept", "application/json")
				.header("korisnik", korisnik)
				.header("zeton", zeton)
				.post(Entity.json(icao));
		
		if(restOdgovorDodaj.getStatus()==200) {
			return true;
		}
		
		
		return false;
	}
	
	/**
	 * Izracunaj udaljenost.
	 *
	 * @param gsPrvi the gs prvi
	 * @param gdPrvi the gd prvi
	 * @param gsDrugi the gs drugi
	 * @param gdDrugi the gd drugi
	 * @return the integer
	 */
	private Integer izracunajUdaljenost(Double gsPrvi, Double gdPrvi, Double gsDrugi, Double gdDrugi) {
		gsPrvi = Math.toRadians(gsPrvi);
		gdPrvi = Math.toRadians(gdPrvi);
		gsDrugi = Math.toRadians(gsDrugi);
		gdDrugi = Math.toRadians(gdDrugi);

		double radijusZemlje = 6371.01;
		double udaljenost = radijusZemlje * Math.acos(Math.sin(gsPrvi) * Math.sin(gsDrugi)
				+ Math.cos(gsPrvi) * Math.cos(gsDrugi) * Math.cos(gdPrvi - gdDrugi));
		return (int) Math.round(udaljenost);
	}

	/**
	 * Veza na bazu podataka.
	 *
	 * @return the postavke baza podataka
	 */
	public PostavkeBazaPodataka dajPBP() {
		ServletContext context = (ServletContext) wsContext.getMessageContext().get(MessageContext.SERVLET_CONTEXT);
		PostavkeBazaPodataka pbp = (PostavkeBazaPodataka) context.getAttribute("Postavke");
		return pbp;
	}

}
