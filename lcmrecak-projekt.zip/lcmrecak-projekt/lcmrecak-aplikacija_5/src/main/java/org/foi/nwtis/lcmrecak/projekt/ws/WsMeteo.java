package org.foi.nwtis.lcmrecak.projekt.ws;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.podaci.Aerodrom;
import org.foi.nwtis.rest.klijenti.NwtisRestIznimka;
import org.foi.nwtis.rest.klijenti.OWMKlijent;
import org.foi.nwtis.rest.podaci.Lokacija;
import org.foi.nwtis.rest.podaci.MeteoPodaci;

import com.google.gson.Gson;

import jakarta.annotation.Resource;
import jakarta.jws.WebMethod;
import jakarta.jws.WebService;
import jakarta.servlet.ServletContext;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response;
import jakarta.xml.ws.WebServiceContext;
import jakarta.xml.ws.handler.MessageContext;

/**
 * Klasa WsMeteo.
 */
@WebService(serviceName = "meteo")
public class WsMeteo {
	
	/** The ws context. */
	@Resource
	private WebServiceContext wsContext;

	/**
	 * Daj meteo.
	 *
	 * @param korisnik the korisnik
	 * @param zeton the zeton
	 * @param icao the icao
	 * @return the meteo podaci
	 */
	@WebMethod
	public MeteoPodaci dajMeteo(String korisnik, String zeton, String icao) {

		List<Aerodrom> aerodromi = new ArrayList<>();
		Client client = ClientBuilder.newClient();
		WebTarget webResource = client.target(dajPBP().dajPostavku("aplikacija3.adresa")).path("aerodromi");

		Response restOdgovor = webResource.request().header("Accept", "application/json")
				.header("korisnik", korisnik)
				.header("zeton", zeton)
				.get();

		if (restOdgovor.getStatus() == 200) {
			String odgovor = restOdgovor.readEntity(String.class);
			Gson gson = new Gson();
			aerodromi = new ArrayList<>();
			aerodromi.addAll(Arrays.asList(gson.fromJson(odgovor, Aerodrom[].class)));
		}

		Aerodrom aerodrom = null;

		for (Aerodrom a : aerodromi) {
			if (a.getIcao().compareTo(icao) == 0) {
				aerodrom = a;
			}
		}

		Lokacija lokacija = aerodrom.getLokacija();
		
		PostavkeBazaPodataka pbp = dajPBP();

		String apikey = pbp.dajPostavku("OpenWeatherMap.apikey");

		OWMKlijent owmKlijent = new OWMKlijent(apikey);
		MeteoPodaci meteoPodaci = null;
		try {
			meteoPodaci = owmKlijent.getRealTimeWeather(lokacija.getLongitude(), lokacija.getLatitude());
		} catch (NwtisRestIznimka e) {
			e.printStackTrace();
		}

		return meteoPodaci;
	}

	/**
	 * Veza na bazu poadataka.
	 *
	 * @return the postavke baza podataka
	 */
	public PostavkeBazaPodataka dajPBP() {
		ServletContext context = (ServletContext) wsContext.getMessageContext().get(MessageContext.SERVLET_CONTEXT);
		PostavkeBazaPodataka pbp = (PostavkeBazaPodataka) context.getAttribute("Postavke");
		return pbp;
	}

}
