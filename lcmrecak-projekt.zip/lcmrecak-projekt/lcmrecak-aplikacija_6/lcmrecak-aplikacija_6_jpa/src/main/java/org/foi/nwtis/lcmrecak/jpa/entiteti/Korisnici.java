package org.foi.nwtis.lcmrecak.jpa.entiteti;

import java.io.Serializable;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


/**
 * Stalna klasa za KORISNICI database table.
 * 
 */
@Entity
@Table(name="KORISNICI")
@NamedQuery(name="Korisnici.findAll", query="SELECT k FROM Korisnici k")
public class Korisnici implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The korisnik. */
	@Id
	@Column(unique=true, nullable=false, length=20)
	private String korisnik;

	/** The email. */
	@Column(length=100)
	private String email;

	/** The ime. */
	@Column(length=25)
	private String ime;

	/** The lozinka. */
	@Column(length=20)
	private String lozinka;

	/** The prezime. */
	@Column(length=25)
	private String prezime;

	/** The putovanjas. */
	//bi-directional many-to-one association to Putovanja
	@OneToMany(mappedBy="korisnici")
	private List<Putovanja> putovanjas;

	/** The grupes. */
	//bi-directional many-to-many association to Grupe
	@ManyToMany
	@JoinTable(
		name="ULOGE"
		, joinColumns={
			@JoinColumn(name="KORISNIK", nullable=false)
			}
		, inverseJoinColumns={
			@JoinColumn(name="GRUPA", nullable=false)
			}
		)
	private List<Grupe> grupes;

	/**
	 * Konstruktor klase Korisnici.
	 */
	public Korisnici() {
	}

	/**
	 * Dohvaća korisnika.
	 *
	 * @return the korisnik
	 */
	public String getKorisnik() {
		return this.korisnik;
	}

	/**
	 * Postavlja korisnika.
	 *
	 * @param korisnik the new korisnik
	 */
	public void setKorisnik(String korisnik) {
		this.korisnik = korisnik;
	}

	/**
	 * Dohvaća email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return this.email;
	}

	/**
	 * Postavlja email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Dohvaća ime.
	 *
	 * @return the ime
	 */
	public String getIme() {
		return this.ime;
	}

	/**
	 * Postavlja ime.
	 *
	 * @param ime the new ime
	 */
	public void setIme(String ime) {
		this.ime = ime;
	}

	/**
	 * Dohvaća lozinku.
	 *
	 * @return the lozinka
	 */
	public String getLozinka() {
		return this.lozinka;
	}

	/**
	 * Postavlja lozinka.
	 *
	 * @param lozinka the new lozinka
	 */
	public void setLozinka(String lozinka) {
		this.lozinka = lozinka;
	}

	/**
	 * Dohvaća prezime.
	 *
	 * @return the prezime
	 */
	public String getPrezime() {
		return this.prezime;
	}

	/**
	 * Postavlja prezime.
	 *
	 * @param prezime the new prezime
	 */
	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}

	/**
	 * Dohvaća putovanjas.
	 *
	 * @return the putovanjas
	 */
	public List<Putovanja> getPutovanjas() {
		return this.putovanjas;
	}

	/**
	 * Postavlja putovanjas.
	 *
	 * @param putovanjas the new putovanjas
	 */
	public void setPutovanjas(List<Putovanja> putovanjas) {
		this.putovanjas = putovanjas;
	}

	/**
	 * Dodaje putovanja.
	 *
	 * @param putovanja the putovanja
	 * @return the putovanja
	 */
	public Putovanja addPutovanja(Putovanja putovanja) {
		getPutovanjas().add(putovanja);
		putovanja.setKorisnici(this);

		return putovanja;
	}

	/**
	 * Briše putovanja.
	 *
	 * @param putovanja the putovanja
	 * @return the putovanja
	 */
	public Putovanja removePutovanja(Putovanja putovanja) {
		getPutovanjas().remove(putovanja);
		putovanja.setKorisnici(null);

		return putovanja;
	}

	/**
	 * Dohvaća grupes.
	 *
	 * @return the grupes
	 */
	public List<Grupe> getGrupes() {
		return this.grupes;
	}

	/**
	 * Postavlja grupes.
	 *
	 * @param grupes the new grupes
	 */
	public void setGrupes(List<Grupe> grupes) {
		this.grupes = grupes;
	}

}