package org.foi.nwtis.lcmrecak.jpa.entiteti;

import java.io.Serializable;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


// TODO: Auto-generated Javadoc
/**
 * The persistent class for the PUTOVANJA database table.
 * 
 */
@Entity
@Table(name="PUTOVANJA")
@NamedQuery(name="Putovanja.findAll", query="SELECT p FROM Putovanja p")
public class Putovanja implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(unique=true, nullable=false)
	private int id;

	/** The aerodrompocetni. */
	@Column(nullable=false, length=10)
	private String aerodrompocetni;

	/** The aerodromzavrsni. */
	@Column(nullable=false, length=10)
	private String aerodromzavrsni;

	/** The vrijemeprvogleta. */
	@Column(nullable=false)
	private int vrijemeprvogleta;

	/** The korisnici. */
	//bi-directional many-to-one association to Korisnici
	@ManyToOne
	@JoinColumn(name="KORISNIK", nullable=false)
	private Korisnici korisnici;

	/** The putovanja letovis. */
	//bi-directional many-to-one association to PutovanjaLetovi
	@OneToMany(mappedBy="putovanja")
	private List<PutovanjaLetovi> putovanjaLetovis;

	/**
	 * Instantiates a new putovanja.
	 */
	public Putovanja() {
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets the aerodrompocetni.
	 *
	 * @return the aerodrompocetni
	 */
	public String getAerodrompocetni() {
		return this.aerodrompocetni;
	}

	/**
	 * Sets the aerodrompocetni.
	 *
	 * @param aerodrompocetni the new aerodrompocetni
	 */
	public void setAerodrompocetni(String aerodrompocetni) {
		this.aerodrompocetni = aerodrompocetni;
	}

	/**
	 * Gets the aerodromzavrsni.
	 *
	 * @return the aerodromzavrsni
	 */
	public String getAerodromzavrsni() {
		return this.aerodromzavrsni;
	}

	/**
	 * Sets the aerodromzavrsni.
	 *
	 * @param aerodromzavrsni the new aerodromzavrsni
	 */
	public void setAerodromzavrsni(String aerodromzavrsni) {
		this.aerodromzavrsni = aerodromzavrsni;
	}

	/**
	 * Gets the vrijemeprvogleta.
	 *
	 * @return the vrijemeprvogleta
	 */
	public int getVrijemeprvogleta() {
		return this.vrijemeprvogleta;
	}

	/**
	 * Sets the vrijemeprvogleta.
	 *
	 * @param vrijemeprvogleta the new vrijemeprvogleta
	 */
	public void setVrijemeprvogleta(int vrijemeprvogleta) {
		this.vrijemeprvogleta = vrijemeprvogleta;
	}

	/**
	 * Gets the korisnici.
	 *
	 * @return the korisnici
	 */
	public Korisnici getKorisnici() {
		return this.korisnici;
	}

	/**
	 * Sets the korisnici.
	 *
	 * @param korisnici the new korisnici
	 */
	public void setKorisnici(Korisnici korisnici) {
		this.korisnici = korisnici;
	}

	/**
	 * Gets the putovanja letovis.
	 *
	 * @return the putovanja letovis
	 */
	public List<PutovanjaLetovi> getPutovanjaLetovis() {
		return this.putovanjaLetovis;
	}

	/**
	 * Sets the putovanja letovis.
	 *
	 * @param putovanjaLetovis the new putovanja letovis
	 */
	public void setPutovanjaLetovis(List<PutovanjaLetovi> putovanjaLetovis) {
		this.putovanjaLetovis = putovanjaLetovis;
	}

	/**
	 * Adds the putovanja letovi.
	 *
	 * @param putovanjaLetovi the putovanja letovi
	 * @return the putovanja letovi
	 */
	public PutovanjaLetovi addPutovanjaLetovi(PutovanjaLetovi putovanjaLetovi) {
		getPutovanjaLetovis().add(putovanjaLetovi);
		putovanjaLetovi.setPutovanja(this);

		return putovanjaLetovi;
	}

	/**
	 * Removes the putovanja letovi.
	 *
	 * @param putovanjaLetovi the putovanja letovi
	 * @return the putovanja letovi
	 */
	public PutovanjaLetovi removePutovanjaLetovi(PutovanjaLetovi putovanjaLetovi) {
		getPutovanjaLetovis().remove(putovanjaLetovi);
		putovanjaLetovi.setPutovanja(null);

		return putovanjaLetovi;
	}

}