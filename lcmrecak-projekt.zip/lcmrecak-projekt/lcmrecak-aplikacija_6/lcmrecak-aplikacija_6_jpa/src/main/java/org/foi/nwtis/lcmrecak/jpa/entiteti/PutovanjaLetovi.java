package org.foi.nwtis.lcmrecak.jpa.entiteti;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;


// TODO: Auto-generated Javadoc
/**
 * The persistent class for the PUTOVANJA_LETOVI database table.
 * 
 */
@Entity
@Table(name="PUTOVANJA_LETOVI")
@NamedQuery(name="PutovanjaLetovi.findAll", query="SELECT p FROM PutovanjaLetovi p")
public class PutovanjaLetovi implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@Column(unique=true, nullable=false)
	private int id;

	/** The avion. */
	@Column(nullable=false, length=30)
	private String avion;

	/** The vrijemeleta. */
	@Column(nullable=false)
	private int vrijemeleta;

	/** The putovanja. */
	//bi-directional many-to-one association to Putovanja
	@ManyToOne
	@JoinColumn(name="PUTOVANJE", nullable=false)
	private Putovanja putovanja;

	/**
	 * Instantiates a new putovanja letovi.
	 */
	public PutovanjaLetovi() {
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets the avion.
	 *
	 * @return the avion
	 */
	public String getAvion() {
		return this.avion;
	}

	/**
	 * Sets the avion.
	 *
	 * @param avion the new avion
	 */
	public void setAvion(String avion) {
		this.avion = avion;
	}

	/**
	 * Gets the vrijemeleta.
	 *
	 * @return the vrijemeleta
	 */
	public int getVrijemeleta() {
		return this.vrijemeleta;
	}

	/**
	 * Sets the vrijemeleta.
	 *
	 * @param vrijemeleta the new vrijemeleta
	 */
	public void setVrijemeleta(int vrijemeleta) {
		this.vrijemeleta = vrijemeleta;
	}

	/**
	 * Gets the putovanja.
	 *
	 * @return the putovanja
	 */
	public Putovanja getPutovanja() {
		return this.putovanja;
	}

	/**
	 * Sets the putovanja.
	 *
	 * @param putovanja the new putovanja
	 */
	public void setPutovanja(Putovanja putovanja) {
		this.putovanja = putovanja;
	}

}