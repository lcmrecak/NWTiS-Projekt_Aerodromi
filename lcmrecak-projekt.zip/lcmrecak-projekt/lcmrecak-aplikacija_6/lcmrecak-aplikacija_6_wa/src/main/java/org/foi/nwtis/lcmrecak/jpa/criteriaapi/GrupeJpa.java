package org.foi.nwtis.lcmrecak.jpa.criteriaapi;

import java.util.List;

import org.foi.nwtis.lcmrecak.jpa.entiteti.Grupe;
import org.foi.nwtis.lcmrecak.jpa.entiteti.Grupe_;

import jakarta.annotation.PostConstruct;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Root;

// TODO: Auto-generated Javadoc
/**
 * The Class GrupeJpa.
 */
@Stateless
public class GrupeJpa {
	
	/** The em. */
	@PersistenceContext(unitName = "NWTiS_lcmrecak_PU")
	private EntityManager em;
	
	/** The cb. */
	private CriteriaBuilder cb;

	/**
	 * Inits the.
	 */
	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}

	/**
	 * Creates the.
	 *
	 * @param grupe the grupe
	 */
	public void create(Grupe grupe) {
		em.persist(grupe);
	}

	/**
	 * Edits the.
	 *
	 * @param grupe the grupe
	 */
	public void edit(Grupe grupe) {
		em.merge(grupe);
	}

	/**
	 * Removes the.
	 *
	 * @param grupe the grupe
	 */
	public void remove(Grupe grupe) {
		em.remove(em.merge(grupe));
	}

	/**
	 * Find.
	 *
	 * @param id the id
	 * @return the grupe
	 */
	public Grupe find(Object id) {
		return em.find(Grupe.class, id);
	}

	/**
	 * Find all.
	 *
	 * @return the list
	 */
	public List<Grupe> findAll() {
		CriteriaQuery<Grupe> cq = cb.createQuery(Grupe.class);
		cq.select(cq.from(Grupe.class));
		return em.createQuery(cq).getResultList();
	}

	/**
	 * Find all.
	 *
	 * @param naziv the naziv
	 * @return the list
	 */
	public List<Grupe> findAll(String naziv) {
		CriteriaQuery<Grupe> cq = cb.createQuery(Grupe.class);
		Root<Grupe> grupe = cq.from(Grupe.class);
		Expression<String> zaNaziv = grupe.get(Grupe_.naziv);
		cq.where(cb.like(zaNaziv, naziv));
		TypedQuery<Grupe> q = em.createQuery(cq);
		return q.getResultList();
	}

	/**
	 * Find range.
	 *
	 * @param odBroja the od broja
	 * @param broj the broj
	 * @return the list
	 */
	public List<Grupe> findRange(int odBroja, int broj) {
		CriteriaQuery<Grupe> cq = cb.createQuery(Grupe.class);
		cq.select(cq.from(Grupe.class));
		TypedQuery<Grupe> q = em.createQuery(cq);
		q.setMaxResults(broj);
		q.setFirstResult(odBroja);
		return q.getResultList();
	}

	/**
	 * Count.
	 *
	 * @return the int
	 */
	public int count() {
		CriteriaQuery<Grupe> cq = cb.createQuery(Grupe.class);
		Root<Grupe> rt = cq.from(Grupe.class);
		cq.multiselect(cb.count(rt));
		Query q = em.createQuery(cq);
		return ((Long) q.getSingleResult()).intValue();
	}
}
