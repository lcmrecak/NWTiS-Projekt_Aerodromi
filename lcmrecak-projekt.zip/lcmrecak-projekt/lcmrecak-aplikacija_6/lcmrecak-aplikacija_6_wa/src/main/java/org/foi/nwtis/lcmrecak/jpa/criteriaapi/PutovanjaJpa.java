package org.foi.nwtis.lcmrecak.jpa.criteriaapi;

import java.util.List;

import org.foi.nwtis.lcmrecak.jpa.entiteti.Putovanja;
import org.foi.nwtis.lcmrecak.jpa.entiteti.Putovanja_;

import jakarta.annotation.PostConstruct;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Root;

// TODO: Auto-generated Javadoc
/**
 * The Class PutovanjaJpa.
 */
@Stateless
public class PutovanjaJpa {
	
	/** The em. */
	@PersistenceContext(unitName = "NWTiS_lcmrecak_PU")
	private EntityManager em;
	
	/** The cb. */
	private CriteriaBuilder cb;

	/**
	 * Inits the.
	 */
	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}

	/**
	 * Creates the.
	 *
	 * @param putovanja the putovanja
	 */
	public void create(Putovanja putovanja) {
		em.persist(putovanja);
	}

	/**
	 * Edits the.
	 *
	 * @param putovanja the putovanja
	 */
	public void edit(Putovanja putovanja) {
		em.merge(putovanja);
	}

	/**
	 * Removes the.
	 *
	 * @param putovanja the putovanja
	 */
	public void remove(Putovanja putovanja) {
		em.remove(em.merge(putovanja));
	}

	/**
	 * Find.
	 *
	 * @param id the id
	 * @return the putovanja
	 */
	public Putovanja find(Object id) {
		return em.find(Putovanja.class, id);
	}

	/**
	 * Find all.
	 *
	 * @return the list
	 */
	public List<Putovanja> findAll() {
		CriteriaQuery<Putovanja> cq = cb.createQuery(Putovanja.class);
		cq.select(cq.from(Putovanja.class));
		return em.createQuery(cq).getResultList();
	}

	/**
	 * Find all departure.
	 *
	 * @param icao the icao
	 * @return the list
	 */
	public List<Putovanja> findAllDeparture(String icao) {
		CriteriaQuery<Putovanja> cq = cb.createQuery(Putovanja.class);
		Root<Putovanja> putovanja = cq.from(Putovanja.class);
		Expression<String> zaAerodrom = putovanja.get(Putovanja_.aerodrompocetni);
		cq.where(cb.like(zaAerodrom, icao));
		TypedQuery<Putovanja> q = em.createQuery(cq);
		return q.getResultList();
	}

	/**
	 * Find all arrival.
	 *
	 * @param icao the icao
	 * @return the list
	 */
	public List<Putovanja> findAllArrival(String icao) {
		CriteriaQuery<Putovanja> cq = cb.createQuery(Putovanja.class);
		Root<Putovanja> putovanja = cq.from(Putovanja.class);
		Expression<String> zaAerodrom = putovanja.get(Putovanja_.aerodromzavrsni);
		cq.where(cb.like(zaAerodrom, icao));
		TypedQuery<Putovanja> q = em.createQuery(cq);
		return q.getResultList();
	}

	/**
	 * Find range.
	 *
	 * @param odBroja the od broja
	 * @param broj the broj
	 * @return the list
	 */
	public List<Putovanja> findRange(int odBroja, int broj) {
		CriteriaQuery<Putovanja> cq = cb.createQuery(Putovanja.class);
		cq.select(cq.from(Putovanja.class));
		TypedQuery<Putovanja> q = em.createQuery(cq);
		q.setMaxResults(broj);
		q.setFirstResult(odBroja);
		return q.getResultList();
	}

	/**
	 * Count.
	 *
	 * @return the int
	 */
	public int count() {
		CriteriaQuery<Putovanja> cq = cb.createQuery(Putovanja.class);
		Root<Putovanja> rt = cq.from(Putovanja.class);
		cq.multiselect(cb.count(rt));
		Query q = em.createQuery(cq);
		return ((Long) q.getSingleResult()).intValue();
	}
}
