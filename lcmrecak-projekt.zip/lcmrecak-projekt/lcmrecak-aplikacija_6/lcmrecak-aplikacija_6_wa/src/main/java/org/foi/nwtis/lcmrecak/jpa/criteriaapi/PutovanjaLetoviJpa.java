package org.foi.nwtis.lcmrecak.jpa.criteriaapi;

import java.util.List;

import org.foi.nwtis.lcmrecak.jpa.entiteti.PutovanjaLetovi;
import org.foi.nwtis.lcmrecak.jpa.entiteti.PutovanjaLetovi_;

import jakarta.annotation.PostConstruct;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Root;

// TODO: Auto-generated Javadoc
/**
 * The Class PutovanjaLetoviJpa.
 */
@Stateless
public class PutovanjaLetoviJpa {
	
	/** The em. */
	@PersistenceContext(unitName = "NWTiS_lcmrecak_PU")
	private EntityManager em;
	
	/** The cb. */
	private CriteriaBuilder cb;

	/**
	 * Inits the.
	 */
	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}

	/**
	 * Creates the.
	 *
	 * @param putovanjaLetovi the putovanja letovi
	 */
	public void create(PutovanjaLetovi putovanjaLetovi) {
		em.persist(putovanjaLetovi);
	}

	/**
	 * Edits the.
	 *
	 * @param putovanjaLetovi the putovanja letovi
	 */
	public void edit(PutovanjaLetovi putovanjaLetovi) {
		em.merge(putovanjaLetovi);
	}

	/**
	 * Removes the.
	 *
	 * @param putovanjaLetovi the putovanja letovi
	 */
	public void remove(PutovanjaLetovi putovanjaLetovi) {
		em.remove(em.merge(putovanjaLetovi));
	}

	/**
	 * Find.
	 *
	 * @param id the id
	 * @return the putovanja letovi
	 */
	public PutovanjaLetovi find(Object id) {
		return em.find(PutovanjaLetovi.class, id);
	}

	/**
	 * Find all.
	 *
	 * @return the list
	 */
	public List<PutovanjaLetovi> findAll() {
		CriteriaQuery<PutovanjaLetovi> cq = cb.createQuery(PutovanjaLetovi.class);
		cq.select(cq.from(PutovanjaLetovi.class));
		return em.createQuery(cq).getResultList();
	}

	/**
	 * Find all airplane.
	 *
	 * @param icao24 the icao 24
	 * @return the list
	 */
	public List<PutovanjaLetovi> findAllAirplane(String icao24) {
		CriteriaQuery<PutovanjaLetovi> cq = cb.createQuery(PutovanjaLetovi.class);
		Root<PutovanjaLetovi> putovanjaLetovi = cq.from(PutovanjaLetovi.class);
		Expression<String> zaAvion = putovanjaLetovi.get(PutovanjaLetovi_.avion);
		cq.where(cb.like(zaAvion, icao24));
		TypedQuery<PutovanjaLetovi> q = em.createQuery(cq);
		return q.getResultList();
	}

	/**
	 * Find range.
	 *
	 * @param odBroja the od broja
	 * @param broj the broj
	 * @return the list
	 */
	public List<PutovanjaLetovi> findRange(int odBroja, int broj) {
		CriteriaQuery<PutovanjaLetovi> cq = cb.createQuery(PutovanjaLetovi.class);
		cq.select(cq.from(PutovanjaLetovi.class));
		TypedQuery<PutovanjaLetovi> q = em.createQuery(cq);
		q.setMaxResults(broj);
		q.setFirstResult(odBroja);
		return q.getResultList();
	}

	/**
	 * Count.
	 *
	 * @return the int
	 */
	public int count() {
		CriteriaQuery<PutovanjaLetovi> cq = cb.createQuery(PutovanjaLetovi.class);
		Root<PutovanjaLetovi> rt = cq.from(PutovanjaLetovi.class);
		cq.multiselect(cb.count(rt));
		Query q = em.createQuery(cq);
		return ((Long) q.getSingleResult()).intValue();
	}
}
