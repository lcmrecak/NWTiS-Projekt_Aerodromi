package org.foi.nwtis.lcmrecak.jpa.jpsql;

import java.util.List;

import org.foi.nwtis.lcmrecak.jpa.entiteti.Korisnici;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

// TODO: Auto-generated Javadoc
/**
 * The Class KorisniciJpaJpsql.
 */
@Stateless
public class KorisniciJpaJpsql {
	
	/** The em. */
	@PersistenceContext(unitName = "NWTiS_lcmrecak_PU")
	private EntityManager em;

	/**
	 * Creates the.
	 *
	 * @param korisnici the korisnici
	 */
	public void create(Korisnici korisnici) {
		em.persist(korisnici);
	}

	/**
	 * Edits the.
	 *
	 * @param korisnici the korisnici
	 */
	public void edit(Korisnici korisnici) {
		em.merge(korisnici);
	}

	/**
	 * Removes the.
	 *
	 * @param korisnici the korisnici
	 */
	public void remove(Korisnici korisnici) {
		em.remove(em.merge(korisnici));
	}

	/**
	 * Find.
	 *
	 * @param id the id
	 * @return the korisnici
	 */
	public Korisnici find(Object id) {
		return em.find(Korisnici.class, id);
	}

	/**
	 * Find all.
	 *
	 * @return the list
	 */
	public List<?> findAll() {
		return em.createQuery(
			    "SELECT k FROM Korisnici k")
			    .getResultList();
	}

	/**
	 * Find all.
	 *
	 * @param prezime the prezime
	 * @param ime the ime
	 * @return the list
	 */
	public List<?> findAll(String prezime, String ime) {
	    return em.createQuery(
	            "SELECT k FROM Korisnici k WHERE k.prezime LIKE :prezime AND k.ime like :ime")
	            .setParameter("prezime", prezime)
	            .setParameter("ime", ime)
	            .getResultList();
	}

	/**
	 * Find range.
	 *
	 * @param odBroja the od broja
	 * @param broj the broj
	 * @return the list
	 */
	public List<?> findRange(int odBroja, int broj) {
		return em.createQuery(
			    "SELECT k FROM Korisnici k")
				.setMaxResults(broj)
				.setFirstResult(odBroja)
			    .getResultList();		
	}

	/**
	 * Count.
	 *
	 * @return the int
	 */
	public int count() {
		return em.createQuery(
			    "SELECT count(k) FROM Korisnici k")
			    .getFirstResult();	
	}
}
