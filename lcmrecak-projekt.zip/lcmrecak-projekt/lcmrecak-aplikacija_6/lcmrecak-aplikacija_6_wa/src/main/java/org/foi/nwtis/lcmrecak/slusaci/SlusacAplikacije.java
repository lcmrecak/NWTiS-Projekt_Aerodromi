package org.foi.nwtis.lcmrecak.slusaci;

import org.foi.nwtis.lcmrecak.vjezba_03.konfiguracije.NeispravnaKonfiguracija;
import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.KonfiguracijaBP;
import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

/**
 * Implementacija slušaća životnog ciklusa aplikacije - klasa SlusacAplikacije.
 */
@WebListener
public class SlusacAplikacije implements ServletContextListener {
	
    /**
     * Početni konstuktor. 
     */
    public SlusacAplikacije() {
    }

	/**
	 * Context inicijaliziran.
	 *
	 * @param sce the sce
	 */
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		ServletContext context = sce.getServletContext();
		String nazivDatoteke = context.getInitParameter("konfiguracija");
		KonfiguracijaBP konfig = null;
		String putanja = context.getRealPath("/WEB-INF") + java.io.File.separator; 
		try {
			konfig = new PostavkeBazaPodataka(putanja + nazivDatoteke);
			konfig.ucitajKonfiguraciju();
			context.setAttribute("Postavke", konfig);
			System.out.println("Učitana konfiguracijska datoteka.");
		} catch (NeispravnaKonfiguracija e1) {
			e1.printStackTrace();
			return;
		}

		ServletContextListener.super.contextInitialized(sce);
	}
	
	/**
	 * Context uništen.
	 *
	 * @param sce the sce
	 */
	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		ServletContext context = sce.getServletContext();
		context.removeAttribute("Postavke");
		
		ServletContextListener.super.contextDestroyed(sce);
	}

}
