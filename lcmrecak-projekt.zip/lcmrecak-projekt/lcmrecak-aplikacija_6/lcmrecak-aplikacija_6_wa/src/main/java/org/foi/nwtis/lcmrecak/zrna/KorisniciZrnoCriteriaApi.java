package org.foi.nwtis.lcmrecak.zrna;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.foi.nwtis.lcmrecak.jpa.criteriaapi.GrupeJpa;
import org.foi.nwtis.lcmrecak.jpa.criteriaapi.KorisniciJpa;
import org.foi.nwtis.lcmrecak.jpa.entiteti.Grupe;
import org.foi.nwtis.lcmrecak.jpa.entiteti.Korisnici;
import org.foi.nwtis.lcmrecak.vjezba_06.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.podaci.Aerodrom;
import org.foi.nwtis.podaci.Korisnik;

import com.google.gson.Gson;

import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.context.ExternalContext;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response;

/**
 * The Class KorisniciZrnoCriteriaApi.
 */
//@ConversationScoped
@SessionScoped
@Named("korisniciZrnoCriteriaApi")
public class KorisniciZrnoCriteriaApi implements Serializable {
	
	/** The serv context. */
	ServletContext servContext = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
	
	/** The pbp. */
	PostavkeBazaPodataka pbp = (PostavkeBazaPodataka) servContext.getAttribute("Postavke");

	/** The ext context. */
	ExternalContext extContext = FacesContext.getCurrentInstance().getExternalContext();
	
	/** The session. */
	HttpSession session = ((HttpServletRequest) extContext.getRequest()).getSession();
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The korisnici jpa. */
	@EJB
	KorisniciJpa korisniciJpa;

	/** The grupe jpa. */
	@EJB
	GrupeJpa grupeJpa;

	/** The poruka. */
	String poruka = null;
	
	/** The korime. */
	String korime = null;
	
	/** The lozinka. */
	String lozinka = null;
	
	/** The zeton. */
	String zeton = null;
	
	/** The korisnici L. */
	private List<Korisnik> korisniciL = new ArrayList<>();
	
	/** The aerodromi L. */
	private List<Aerodrom> aerodromiL =new ArrayList<>();
	
	/** The aerodromi LP. */
	private List<Aerodrom> aerodromiLP =new ArrayList<>();

	/**
	 * Prijava korisnika.
	 *
	 * @return true, if successful
	 */
	public boolean prijavaKorisnika() {
		if (korisniciJpa.find(korime) != null) {
			Client client = ClientBuilder.newClient();
			String zeton = "";
			System.out.println("U SESIJE: " + korime + " " + lozinka);
			WebTarget webResourceProvjere = client.target(pbp.dajPostavku("aplikacija3.adresa")).path("provjere");

			Response restPrijava = webResourceProvjere.request().header("Accept", "application/json")
					.header("korisnik", korime).header("lozinka", lozinka).get();

			if (restPrijava.getStatus() == 200) {
				zeton = restPrijava.readEntity(String.class).split(" ")[1];
				zeton = zeton.substring(0, zeton.length() - 1);

				session.setAttribute("korime", korime);
				session.setAttribute("zeton", zeton);
				session.setAttribute("lozinka", lozinka);

				poruka = "Uspješna prijava";
			} else
				poruka = "Neuspješna prijava: pogrešna lozinka!";
			return true;
		} else {
			poruka = "Neuspješna prijava: korisnik ne postoji!";
			return false;
		}
	}

	/**
	 * Daj sve korisnike zahtjev.
	 *
	 * @return the list
	 */
	public List<Korisnik> dajSveKorisnikeZahtjev() {
		String korisnik = session.getAttribute("korime").toString();
		String zeton = session.getAttribute("zeton").toString();

		Client client = ClientBuilder.newClient();
		WebTarget webResource = client.target(pbp.dajPostavku("aplikacija3.adresa")).path("korisnici");

		Response restOdgovor = webResource.request().header("Accept", "application/json").header("korisnik", korisnik)
				.header("zeton", zeton).get();

		List<Korisnik> korisnici = null;
		if (restOdgovor.getStatus() == 200) {
			String odgovor = restOdgovor.readEntity(String.class);
			Gson gson = new Gson();
			korisnici = new ArrayList<>();
			korisnici.addAll(Arrays.asList(gson.fromJson(odgovor, Korisnik[].class)));
		}

		return korisnici;
	}

	/**
	 * Provjera korisnika.
	 *
	 * @param korisnik the korisnik
	 * @return true, if successful
	 */
	public boolean provjeraKorisnika(String korisnik) {
		List<Korisnici> korisniciLokalno = korisniciJpa.findAll();

		for (Korisnici kL : korisniciLokalno) {
			if (korisnik.equals(kL.getKorisnik())) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Sinkroniziraj korisnike.
	 */
	public void sinkronizirajKorisnike() {
		List<Korisnik> sviKorisnici = dajSveKorisnikeZahtjev();

		for (Korisnik k : sviKorisnici) {
			if (korisniciJpa.find(k.getKorIme()) == null) {
				
				Korisnici noviKorisnik = new Korisnici();
				noviKorisnik.setKorisnik(k.getKorIme());
				noviKorisnik.setIme(k.getIme());
				noviKorisnik.setPrezime(k.getPrezime());
				noviKorisnik.setLozinka(k.getLozinka());
				noviKorisnik.setEmail(k.getEmail());

				korisniciJpa.create(noviKorisnik);
			}
		}
	}
	
	/**
	 * Daj aerodrome za preuzimanje.
	 *
	 * @return the list
	 */
	public List<Aerodrom> dajAerodromeZaPreuzimanje() {
		String korisnik = session.getAttribute("korime").toString();
		String zeton = session.getAttribute("zeton").toString();

		Client client = ClientBuilder.newClient();
		WebTarget webResource = client.target(pbp.dajPostavku("aplikacija3.adresa")).path("aerodromi");

		Response restOdgovor = webResource.request().header("Accept", "application/json").header("korisnik", korisnik)
				.header("zeton", zeton).get();

		List<Aerodrom> aerodromi = null;
		if (restOdgovor.getStatus() == 200) {
			String odgovor = restOdgovor.readEntity(String.class);
			Gson gson = new Gson();
			aerodromi = new ArrayList<>();
			aerodromi.addAll(Arrays.asList(gson.fromJson(odgovor, Aerodrom[].class)));
		}

		return aerodromi;
	}
	
	/** The korisnici. */
	/*
	public List<Aerodrom> dajSveAerodrome() {
		String korisnik = session.getAttribute("korime").toString();
		String zeton = session.getAttribute("zeton").toString();

		Client client = ClientBuilder.newClient();
		WebTarget webResource = client.target(pbp.dajPostavku("aplikacija3.adresa")).path("aerodromi");

		Response restOdgovor = webResource.request().header("Accept", "application/json").header("korisnik", korisnik)
				.header("zeton", zeton).get();

		List<Aerodrom> aerodromi = null;
		if (restOdgovor.getStatus() == 200) {
			String odgovor = restOdgovor.readEntity(String.class);
			Gson gson = new Gson();
			aerodromi = new ArrayList<>();
			aerodromi.addAll(Arrays.asList(gson.fromJson(odgovor, Aerodrom[].class)));
		}

		return aerodromi;
	}
*/
	List<Korisnici> korisnici = new ArrayList<>();
	
	/** The korisnik. */
	Korisnici korisnik = new Korisnici();
	
	/** The grupa. */
	Grupe grupa = new Grupe();

	/** The trazi grupe. */
	boolean traziGrupe = false;

	/**
	 * Dohvaća korisnici.
	 *
	 * @return the korisnici
	 */
	public List<Korisnici> getKorisnici() {
		if (!traziGrupe) {
			korisnici = this.dajSveKorisnike();
		}
		return korisnici;
	}

	/**
	 * Postavlja korisnici.
	 *
	 * @param korisnici the new korisnici
	 */
	public void setKorisnici(List<Korisnici> korisnici) {
		this.korisnici = korisnici;
	}

	/**
	 * Dohvaća korisnik.
	 *
	 * @return the korisnik
	 */
	public Korisnici getKorisnik() {
		return korisnik;
	}

	/**
	 * Postavlja korisnik.
	 *
	 * @param korisnik the new korisnik
	 */
	public void setKorisnik(Korisnici korisnik) {
		this.korisnik = korisnik;
	}

	/**
	 * Dohvaća grupa.
	 *
	 * @return the grupa
	 */
	public Grupe getGrupa() {
		return grupa;
	}

	/**
	 * Postavlja grupa.
	 *
	 * @param grupa the new grupa
	 */
	public void setGrupa(Grupe grupa) {
		this.grupa = grupa;
	}

	/**
	 * Daj sve korisnike.
	 *
	 * @return the list
	 */
	public List<Korisnici> dajSveKorisnike() {
		List<Korisnici> lKorisnicii = (List<Korisnici>) korisniciJpa.findAll();

		return lKorisnicii;
	}

	/**
	 * Odabir korisnika.
	 *
	 * @param korisnikId the korisnik id
	 * @return the string
	 */
	public String odabirKorisnika(String korisnikId) {
		this.korisnik = korisniciJpa.find(korisnikId);
		return "";
	}

	/**
	 * Odabir grupe.
	 *
	 * @param grupaId the grupa id
	 * @return the string
	 */
	public String odabirGrupe(String grupaId) {
		this.grupa = grupeJpa.find(grupaId);
		traziGrupe = true;
		this.korisnici = this.grupa.getKorisnicis();
		return "";
	}

	/**
	 * Dohvaća poruka.
	 *
	 * @return the poruka
	 */
	public String getPoruka() {
		return poruka;
	}

	/**
	 * Postavlja poruka.
	 *
	 * @param poruka the new poruka
	 */
	public void setPoruka(String poruka) {
		this.poruka = poruka;
	}

	/**
	 * Dohvaća korime.
	 *
	 * @return the korime
	 */
	public String getKorime() {
		return korime;
	}

	/**
	 * Postavlja korime.
	 *
	 * @param korime the new korime
	 */
	public void setKorime(String korime) {
		this.korime = korime;
	}

	/**
	 * Dohvaća lozinka.
	 *
	 * @return the lozinka
	 */
	public String getLozinka() {
		return lozinka;
	}

	/**
	 * Postavlja lozinka.
	 *
	 * @param lozinka the new lozinka
	 */
	public void setLozinka(String lozinka) {
		this.lozinka = lozinka;
	}

	/**
	 * Dohvaća serv context.
	 *
	 * @return the serv context
	 */
	public ServletContext getServContext() {
		return servContext;
	}

	/**
	 * Postavlja serv context.
	 *
	 * @param servContext the new serv context
	 */
	public void setServContext(ServletContext servContext) {
		this.servContext = servContext;
	}

	/**
	 * Dohvaća pbp.
	 *
	 * @return the pbp
	 */
	public PostavkeBazaPodataka getPbp() {
		return pbp;
	}

	/**
	 * Postavlja pbp.
	 *
	 * @param pbp the new pbp
	 */
	public void setPbp(PostavkeBazaPodataka pbp) {
		this.pbp = pbp;
	}

	/**
	 * Dohvaća ext context.
	 *
	 * @return the ext context
	 */
	public ExternalContext getExtContext() {
		return extContext;
	}

	/**
	 * Postavlja ext context.
	 *
	 * @param extContext the new ext context
	 */
	public void setExtContext(ExternalContext extContext) {
		this.extContext = extContext;
	}

	/**
	 * Dohvaća session.
	 *
	 * @return the session
	 */
	public HttpSession getSession() {
		return session;
	}

	/**
	 * Postavlja session.
	 *
	 * @param session the new session
	 */
	public void setSession(HttpSession session) {
		this.session = session;
	}

	/**
	 * Dohvaća korisnici L.
	 *
	 * @return the korisnici L
	 */
	public List<Korisnik> getKorisniciL() {
		this.korisniciL = this.dajSveKorisnikeZahtjev();
		return korisniciL;
	}

	/**
	 * Postavlja korisnici L.
	 *
	 * @param korisniciL the new korisnici L
	 */
	public void setKorisniciL(List<Korisnik> korisniciL) {
		this.korisniciL = korisniciL;
	}

	/**
	 * Dohvaća zeton.
	 *
	 * @return the zeton
	 */
	public String getZeton() {
		return zeton;
	}

	/**
	 * Postavlja zeton.
	 *
	 * @param zeton the new zeton
	 */
	public void setZeton(String zeton) {
		this.zeton = zeton;
	}

	/**
	 * Dohvaća aerodromi L.
	 *
	 * @return the aerodromi L
	 */
	public List<Aerodrom> getAerodromiL() {
		this.aerodromiL = this.dajAerodromeZaPreuzimanje();
		return aerodromiL;
	}

	/**
	 * Postavlja aerodromi L.
	 *
	 * @param aerodromiL the new aerodromi L
	 */
	public void setAerodromiL(List<Aerodrom> aerodromiL) {
		this.aerodromiL = aerodromiL;
	}
/*
	public List<Aerodrom> getAerodromiLP() {
		this.aerodromiLP = this.dajSveAerodrome();
		return aerodromiLP;
	}

	public void setAerodromiLP(List<Aerodrom> aerodromiLP) {
		this.aerodromiLP = aerodromiLP;
	}
*/	
	

}