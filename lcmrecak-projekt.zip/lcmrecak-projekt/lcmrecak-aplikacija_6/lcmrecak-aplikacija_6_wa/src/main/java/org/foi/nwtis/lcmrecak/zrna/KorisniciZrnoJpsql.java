package org.foi.nwtis.lcmrecak.zrna;

import java.util.ArrayList;
import java.util.List;

import org.foi.nwtis.lcmrecak.jpa.entiteti.Korisnici;
import org.foi.nwtis.lcmrecak.jpa.jpsql.KorisniciJpaJpsql;

import jakarta.ejb.EJB;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;

/**
 * Klasa KorisniciZrnoJpsql.
 */
@RequestScoped
@Named("korisniciZrnoJpsql")
public class KorisniciZrnoJpsql {
	
	/** The korisnici jpa. */
	@EJB
	KorisniciJpaJpsql korisniciJpa;

	/** The korisnici. */
	List<Korisnici> korisnici = new ArrayList<>();

	/**
	 * Dohvaća korisnici.
	 *
	 * @return the korisnici
	 */
	public List<Korisnici> getKorisnici() {
		return korisnici = this.dajSveKorisnike();
	}

	/**
	 * Postavlja korisnici.
	 *
	 * @param korisnici the new korisnici
	 */
	public void setKorisnici(List<Korisnici> korisnici) {
		this.korisnici = korisnici;
	}

	/**
	 * Daj sve korisnike.
	 *
	 * @return the list
	 */
	public List<Korisnici> dajSveKorisnike() {

		List<Korisnici> lKorisnicii = (List<Korisnici>) korisniciJpa.findAll();

		return lKorisnicii;
	}
}