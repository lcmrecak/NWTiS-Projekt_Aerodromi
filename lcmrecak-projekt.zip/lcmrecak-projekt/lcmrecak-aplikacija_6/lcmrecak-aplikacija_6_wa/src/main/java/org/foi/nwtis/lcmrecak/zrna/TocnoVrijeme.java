package org.foi.nwtis.lcmrecak.zrna;

import java.util.Date;

import org.foi.nwtis.lcmrecak.zrna.jms.PosiljateljPoruke;

import jakarta.annotation.Resource;
import jakarta.ejb.EJB;
import jakarta.ejb.Schedule;
import jakarta.ejb.Singleton;
import jakarta.ejb.Startup;
import jakarta.ejb.TimerService;

// TODO: Auto-generated Javadoc
/**
 * The Class TocnoVrijeme.
 */
@Singleton
@Startup
public class TocnoVrijeme {
	
	/** The timer service. */
	@Resource
	TimerService timerService;

	/** The posiljatelj poruke. */
	@EJB
	PosiljateljPoruke posiljateljPoruke;

	/**
	 * Slanje poruke.
	 */
	@Schedule(minute = "*/1", hour = "*", persistent = false)
	public void slanjePoruke() {
		posiljateljPoruke.noviPoruka("Sada je: " + new Date().toString());
	}

}